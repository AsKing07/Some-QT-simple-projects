#ifndef SCORE_H
#define SCORE_H

#include <QMainWindow>
#include "supuser.h"
#include "fenetre.h"
#include "admin.h"
#include "choix.h"
#include "ads.h"
#include "fake.h"
#include "table.h"
#include "choice.h"
#include "cont.h"
#include "finder.h"
#include "form.h"
#include "formul.h"

namespace Ui {
class Score;
}

class Score : public QMainWindow
{
    Q_OBJECT

public:
    explicit Score(QWidget *parent = nullptr);
    ~Score();

private slots:
    void on_pushButton_2_clicked();

    void on_pushButton_clicked();

private:
    Ui::Score *ui;
    QSqlQuery q;
};

#endif // SCORE_H
