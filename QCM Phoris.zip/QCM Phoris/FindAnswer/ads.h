#ifndef ADS_H
#define ADS_H

#include <QMainWindow>
#include "supuser.h"
#include "fenetre.h"
#include "choice.h"
#include "cont.h"
#include "score.h"
#include "choix.h"
#include "fake.h"
#include "table.h"
#include "finder.h"
#include "form.h"
#include "formul.h"

namespace Ui {
class Ads;
}

class Ads : public QMainWindow
{
    Q_OBJECT

public:
    explicit Ads(QWidget *parent = nullptr);
    ~Ads();

public slots:
    void input();

private slots:
    void on_pushButton_3_clicked();

    void on_pushButton_4_clicked();

    void on_pushButton_2_clicked();

    void on_pushButton_5_clicked();

private:
    Ui::Ads *ui;
    QSqlQuery k,r,q;
};

#endif // ADS_H
