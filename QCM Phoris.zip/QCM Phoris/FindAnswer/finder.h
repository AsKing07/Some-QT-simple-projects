#ifndef FINDER_H
#define FINDER_H
#include "User.h"
#include <QMainWindow>
#include "supuser.h"
#include "fenetre.h"
#include "choice.h"
#include "cont.h"
#include "score.h"
#include "choix.h"
#include "fake.h"
#include "ads.h"
#include "table.h"
#include "admin.h"
#include "form.h"
#include "formul.h"

namespace Ui {
class Finder;
}

class Finder : public QMainWindow
{
    Q_OBJECT

public:
    explicit Finder(QWidget *parent = nullptr);
    ~Finder();

private slots:
    void on_pushButton_3_clicked();

    void on_pushButton_2_clicked();

    void on_pushButton_5_clicked();

    void on_pushButton_4_clicked();

    void on_pushButton_6_clicked();

private:
    Ui::Finder *ui;
    QSqlQuery q,k,r;

};

#endif // FINDER_H
