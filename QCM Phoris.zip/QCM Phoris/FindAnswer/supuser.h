#ifndef SUPUSER_H
#define SUPUSER_H

#include <QMainWindow>
#include <QString>
#include <ctime>
#include<QInputDialog>
#include <QMessageBox>
#include <QTimer>
#include <QMainWindow>
#include <QRandomGenerator>
#include <QPushButton>
#include <QWidget>
#include <QLineEdit>
#include <QLabel>
#include <QSqlDatabase>
#include<QSqlError>
#include<QMessageBox>
#include <QSqlQuery>
#include <QSqlQueryModel>
#include<QDebug>
#include "admin.h"
#include "fenetre.h"
#include "choice.h"
#include "cont.h"
#include "score.h"
#include "choix.h"
#include "fake.h"
#include "table.h"
#include "finder.h"
#include "ads.h"
#include "form.h"
#include "formul.h"

namespace Ui {
class SupUser;
}

class SupUser : public QMainWindow
{
    Q_OBJECT

public:
    explicit SupUser(QWidget *parent = nullptr);
    ~SupUser();

public slots:
    void numpartie();
    void reset2();
    void reset();
    void desc();
    void time1();
    void point();
    void fin();
    void rec();
    void next();

private slots:
    void on_quitter_clicked();

    void on_passed_clicked();

    void on_pushButton_5_clicked();

    void on_ans1_clicked();

    void on_ans2_clicked();

    void on_ans3_clicked();

    void on_ans4_clicked();

    void on_effacer_clicked();

private:
    Ui::SupUser *ui;
    QTimer *temps1;
    QTimer *compte;
    int decompte=15;
    int tour=0,tmaker,scorer;
    int tempsActuel=0,tempsact=0,teml=0;
    int nbr=0,nbr0,nbr1,nbr2,nbr3,nbr4,nbr5,nbr6;
    int c1,c2,c3,c4;
    int un,deux,trois,quatre,resultat=0,ans,answer;
    QString op,op1,op2,op3;
    QString nb1,nb2,nb3,nb4,nb5,anr,recup;
    QString ope1,ope2,ope3;
    QSqlQuery q ,k, r;
    QString uno,dos,tres,quatro,cinquo;
};

#endif // SUPUSER_H
