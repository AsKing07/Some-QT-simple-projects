#include "fenetre.h"
#include "ui_fenetre.h"

Fenetre::Fenetre(QWidget *parent)
    : QMainWindow(parent)
    , ui(new Ui::Fenetre)
{
    ui->setupUi(this);
}

Fenetre::~Fenetre()
{
    delete ui;
}


void Fenetre::on_admin_clicked()
{
    Formul *fu=new Formul;
    fu->show();
    this->close();
}


void Fenetre::on_user_clicked()
{
    Choice *gt=new Choice;
    gt->show();
    this->close();
}


void Fenetre::on_pushButton_clicked()
{
    int reponse = QMessageBox::question(this,"Game","Voulez-vous vraiment quitter le Jeu",QMessageBox::Yes|QMessageBox::No);

    if(reponse == QMessageBox::Yes){
        QMessageBox::information(this,"OUPS!!!","Heureux d'avoir pu vous divertir\n\n À la prochaine.....");
        this->close();
    }
    else if(reponse == QMessageBox::No){
        QMessageBox::information(this,"YOUPI!!","Retour au jeu");
    }
}

