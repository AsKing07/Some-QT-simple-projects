#ifndef FENETRE_H
#define FENETRE_H

#include <QMainWindow>
#include <QMessageBox>
#include "supuser.h"
#include "admin.h"
#include "score.h"
#include "choix.h"
#include "fake.h"
#include "table.h"
#include "ads.h"
#include "choice.h"
#include "cont.h"
#include "finder.h"
#include "form.h"
#include "formul.h"

QT_BEGIN_NAMESPACE
namespace Ui { class Fenetre; }
QT_END_NAMESPACE

class Fenetre : public QMainWindow
{
    Q_OBJECT

public:
    Fenetre(QWidget *parent = nullptr);
    ~Fenetre();

private slots:
    void on_admin_clicked();

    void on_user_clicked();

    void on_pushButton_clicked();

private:
    Ui::Fenetre *ui;
};
#endif // FENETRE_H
