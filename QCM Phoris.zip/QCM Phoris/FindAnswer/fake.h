#ifndef FAKE_H
#define FAKE_H

#include <QMainWindow>
#include <QSqlQuery>
#include <QSqlError>
#include "supuser.h"
#include "admin.h"
#include "score.h"
#include "choix.h"
#include "table.h"
#include "ads.h"
#include "choice.h"
#include "cont.h"
#include "finder.h"
#include "form.h"
#include "formul.h"

namespace Ui {
class Fake;
}

class Fake : public QMainWindow
{
    Q_OBJECT

public:
    explicit Fake(QWidget *parent = nullptr);
    ~Fake();

private slots:
    void on_save_clicked();

    void on_delete_2_clicked();

    void on_delet_all_clicked();

    void on_finish_clicked();

    void on_pushButton_5_clicked();

private:
    Ui::Fake *ui;
    QString categorie,un,deux,trois,quatre,cinq,six,sept,huit,neuf,dix;
    QString ans1,ans2,ans3,ans4,ans5;
    QSqlQuery q;
};

#endif // FAKE_H
