#include "form.h"
#include "ui_form.h"

Form::Form(QWidget *parent) :
    QMainWindow(parent),
    ui(new Ui::Form)
{
    ui->setupUi(this);
}

Form::~Form()
{
    delete ui;
}

void Form::on_go_clicked()
{
    if(!ui->pseudo->text().isEmpty()&& !ui->key->text().isEmpty()){
       int count=0;
         QString pseudy;
            q.prepare("SELECT Pseudo,Password FROM User WHERE Pseudo=:pseudy AND Password=:cod");
            q.bindValue(":pseudy",ui->pseudo->text());
            q.bindValue(":cod",ui->key->text());

            if(q.exec()){
                while(q.next()){
                    count++;
                }

                if(count==1){

                    QMessageBox::information(nullptr,pseudy,"Bon retour parmi nous @"+ui->pseudo->text()+"\n\n- - - Nous sommes heureux de vous revoir ! - - -");
                    q.prepare("INSERT INTO Use(Pseudo,Password)" "VALUES(:pseudo,:pass)");
                    q.bindValue(":pseudo",ui->pseudo->text());
                    q.bindValue(":pass",ui->key->text());
                   if(!q.exec()){
                       QMessageBox::information(nullptr,"Erreur lors de l'Insertion des données",q.lastError().text());
                   }

                    SupUser *niv=new SupUser;
                    niv->show();
                    this->close();
                }

                else if(count<1){
                    int count=0;

    if(!ui->pseudo->text().isEmpty()){
            q.prepare("SELECT Pseudo FROM User WHERE Pseudo=:pseud");
            q.bindValue(":pseud",ui->pseudo->text());

            if(q.exec()){
                while(q.next()){
                    count++;
                }

                if(count==1){
                    QMessageBox::information(nullptr,"Erreur","Ce Pseudonyme est déjà utilisé par un autre Utilisateur \n\nVeuillez changer de Pseudo !!\n\n Je vous sais créatif....");
                             ui->pseudo->clear();
                             ui->key->clear();
                             ui->name->clear();
                             ui->prenom->clear();
                }

                else if(count<1){
                      SupUser *Niveau=new SupUser;
                      QString pseudonyme=ui->pseudo->text();
                      QString nom=ui->name->text();
                      QString prenom=ui->prenom->text();
                      QString code=ui->key->text();
                    if(!pseudonyme.isEmpty()&& !nom.isEmpty()&& !prenom.isEmpty()&& !code.isEmpty()){
                        q.prepare("INSERT INTO User(Pseudo,Nom,Prenoms,Password)" "VALUES (:pseudo,:Nom,:Prenom,:keyword)");
                        q.bindValue(":pseudo",pseudonyme);
                        q.bindValue(":Nom",nom);
                        q.bindValue(":Prenom",prenom);
                        q.bindValue(":keyword",code);

                             if(!q.exec())

                                QMessageBox::information(nullptr,"Erreur lors de l'Insertion des données",q.lastError().text());
                             else
                                QMessageBox::information(nullptr,"BIENVENUE","Bienvenue dans ce Nouveau Jeu @"+pseudonyme+"...\n\nNous vous assurons une expérience enrichissante en découvertes et connaissances...");

                             QString po=ui->pseudo->text();
                             QString por=ui->key->text();
                             q.prepare("INSERT INTO Use(Pseudo,Password)" "VALUES(:pseudo,:pass)");
                             q.bindValue(":pseudo",po);
                             q.bindValue(":pass",por);
                             if(!q.exec()){
                                 QMessageBox::information(nullptr,"Erreur lors de l'Insertion des données",q.lastError().text());
                             }

                                  ui->name->clear();
                                  ui->prenom->clear();
                                  ui->pseudo->clear();
                                  ui->key->clear();

                                       Niveau->show();
                                        this->close();

                            }
                      }
                  }

                         else if(!q.exec()){
                               QMessageBox::information(nullptr,"Erreur lors de l'Insertion des données",q.lastError().text());
                         }

                          ui->name->clear();
                          ui->prenom->clear();
                          ui->pseudo->clear();
                          ui->key->clear();

                   }
                 else
              {
                 QMessageBox::critical(nullptr,"Enregistement","Veuillez remplir les champs");
              }
                }
            }

            else if(!q.exec())

                QMessageBox::information(nullptr,"Erreur lors de l'Insertion des données",q.lastError().text());

                             ui->pseudo->clear();
                             ui->key->clear();
                             ui->name->clear();
                             ui->prenom->clear();
        }
        else
        {
           QMessageBox::critical(nullptr,"Enregistement","Veuillez remplir les champs");
        }
}


void Form::on_pushButton_clicked()
{
    Choice *ty=new Choice;
    ty->show();
    this->close();
}


void Form::on_quit_clicked()
{
    int reponse = QMessageBox::question(nullptr,"Game","Voulez-vous vraiment quitter le Jeu",QMessageBox::Yes|QMessageBox::No);

    if(reponse == QMessageBox::Yes){
        QMessageBox::information(nullptr,"OUPS!!!","Heureux d'avoir pu vous divertir\n\n À la prochaine.....");
        this->close();
    }
    else if(reponse == QMessageBox::No){
        QMessageBox::information(nullptr,"YOUPI!!","Retour au jeu");
    }
}

