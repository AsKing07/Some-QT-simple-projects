#include "fake.h"
#include "ui_fake.h"

Fake::Fake(QWidget *parent) :
    QMainWindow(parent),
    ui(new Ui::Fake)
{
    ui->setupUi(this);
}

Fake::~Fake()
{
    delete ui;
}

void Fake::on_save_clicked()
{
    categorie=ui->cat->text();
    un=ui->fake1->text();
    deux=ui->fake2->text();
    trois=ui->fake3->text();
    quatre=ui->fake4->text();
    cinq=ui->fake5->text();
    six=ui->fake6->text();
    sept=ui->fake7->text();
    huit=ui->fake8->text();
    neuf=ui->fake9->text();

    if(!categorie.isEmpty() && !un.isEmpty() && !deux.isEmpty() && !trois.isEmpty() && !quatre.isEmpty() && !cinq.isEmpty() && !six.isEmpty() &&
       !sept.isEmpty() && !huit.isEmpty() && !neuf.isEmpty()){

        q.prepare("INSERT INTO Fak_in(Categorie, fake1, fake2, fake3) VALUES(:cat, :fak1, :fak2, :fak3)");
        q.bindValue(":cat",categorie);
        q.bindValue(":fak1",un);
        q.bindValue(":fak2",deux);
        q.bindValue(":fak3",trois);

        if(!q.exec()){
            QMessageBox::information(this,"Erreur lors de l'Insertion des données", q.lastError().text());
        }

        q.prepare("INSERT INTO Fak_in(Categorie, fake1, fake2, fake3) VALUES(:cat, :fak1, :fak2, :fak3)");
        q.bindValue(":cat",categorie);
        q.bindValue(":fak1",quatre);
        q.bindValue(":fak2",cinq);
        q.bindValue(":fak3",six);

        if(!q.exec()){
            QMessageBox::information(this,"Erreur lors de l'Insertion des données", q.lastError().text());
        }

        q.prepare("INSERT INTO Fak_in(Categorie, fake1, fake2, fake3) VALUES(:cat, :fak1, :fak2, :fak3)");
        q.bindValue(":cat",categorie);
        q.bindValue(":fak1",sept);
        q.bindValue(":fak2",huit);
        q.bindValue(":fak3",neuf);

        if(!q.exec()){
            QMessageBox::information(this,"Erreur lors de l'Insertion des données", q.lastError().text());
        }

        q.prepare("INSERT INTO Cat(Categorie)  VALUES(:cat)");
        q.bindValue(":cat",categorie);

        if(!q.exec()){
            QMessageBox::information(this,"Erreur lors de l'Insertion des données", q.lastError().text());
        }

        on_delet_all_clicked();

    }
    else{
        QMessageBox::critical(this,"INSERTION","Veuillez remplir tous les champs...\n Je vous Sais Créatif");
    }
}


void Fake::on_delete_2_clicked()
{
    categorie=ui->cat->text();
    un=ui->fake1->text();
    deux=ui->fake2->text();
    trois=ui->fake3->text();
    quatre=ui->fake4->text();
    cinq=ui->fake5->text();
    six=ui->fake6->text();
    sept=ui->fake7->text();
    huit=ui->fake8->text();
    neuf=ui->fake9->text();

    if(!categorie.isEmpty()&& un.isEmpty()){
        ui->cat->clear();
    }

    if(!categorie.isEmpty()&& !un.isEmpty()&& deux.isEmpty()){
        ui->fake1->clear();
    }
    if(!categorie.isEmpty()&& !un.isEmpty()&& !deux.isEmpty()&& trois.isEmpty()){
        ui->fake2->clear();
    }
    if(!categorie.isEmpty()&& !un.isEmpty()&& !deux.isEmpty()&& !trois.isEmpty()&& quatre.isEmpty()){
        ui->fake3->clear();
    }
    if(!categorie.isEmpty()&& !un.isEmpty()&& !deux.isEmpty()&& !trois.isEmpty()&& !quatre.isEmpty()&& cinq.isEmpty()){
        ui->fake4->clear();
    }
    if(!categorie.isEmpty()&& !un.isEmpty()&& !deux.isEmpty()&& !trois.isEmpty()&& !quatre.isEmpty()&& !cinq.isEmpty()&& six.isEmpty()){
        ui->fake5->clear();
    }
    if(!categorie.isEmpty()&& !un.isEmpty()&& !deux.isEmpty()&& !trois.isEmpty()&& !quatre.isEmpty()&& !cinq.isEmpty()&& !six.isEmpty()&& sept.isEmpty()){
        ui->fake6->clear();
    }
    if(!categorie.isEmpty()&& !un.isEmpty()&& !deux.isEmpty()&& !trois.isEmpty()&& !quatre.isEmpty()&& !cinq.isEmpty()&& !six.isEmpty()&& !sept.isEmpty()&& huit.isEmpty()){
        ui->fake7->clear();
    }
    if(!categorie.isEmpty()&& !un.isEmpty()&& !deux.isEmpty()&& !trois.isEmpty()&& !quatre.isEmpty()&& !cinq.isEmpty()&& !six.isEmpty()&& !sept.isEmpty()&& !huit.isEmpty()&& neuf.isEmpty()){
        ui->fake8->clear();
    }
    if(!categorie.isEmpty()&& !un.isEmpty()&& !deux.isEmpty()&& !trois.isEmpty()&& !quatre.isEmpty()&& !cinq.isEmpty()&& !six.isEmpty()&& !sept.isEmpty()&& !huit.isEmpty()&& !neuf.isEmpty()&& dix.isEmpty()){
        ui->fake9->clear();
    }
}


void Fake::on_delet_all_clicked()
{
    ui->cat->clear();
    ui->fake1->clear();
    ui->fake2->clear();
    ui->fake3->clear();
    ui->fake4->clear();
    ui->fake5->clear();
    ui->fake6->clear();
    ui->fake7->clear();
    ui->fake8->clear();
    ui->fake9->clear();
}


void Fake::on_finish_clicked()
{
    on_delet_all_clicked();
    Choix *neuf=new Choix;
    neuf->show();
    this->close();
}


void Fake::on_pushButton_5_clicked()
{
    Choix *ch=new Choix;
    ch->show();
    this->hide();
}

