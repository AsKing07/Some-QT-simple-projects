#include "formul.h"
#include "ui_formul.h"

Formul::Formul(QWidget *parent) :
    QMainWindow(parent),
    ui(new Ui::Formul)
{
    ui->setupUi(this);
}

Formul::~Formul()
{
    delete ui;
}

void Formul::on_go_clicked()
{
    int count=0;
    QString po=ui->pseudo->text();
    QString por=ui->key->text();
    if(!ui->pseudo->text().isEmpty()&& !por.isEmpty()){
        QString pd;
        int but=0;
    if(!ui->pseudo->text().isEmpty()){
            q.prepare("SELECT * FROM Admin WHERE Pseudo=:pseud");
            q.bindValue(":pseud",ui->pseudo->text());
            if(q.exec()){
                while(q.next()){
                    but++;
                }

                if(but==1)
                {
                    if(q.last()){
                        pd = q.value(2).toString();
                    }

                    if(pd!=ui->key->text()){
                        QMessageBox::information(nullptr,"Erreur","Pseudo ou Mot de Passe Incorrect");
                                 ui->pseudo->clear();
                                 ui->key->clear();
                    }

                    else{
                q.prepare("SELECT * FROM Admin WHERE Pseudo=:pseudonyme AND Password=:code");
                q.bindValue(":pseudonyme",ui->pseudo->text());
                q.bindValue(":code",ui->key->text());

                if(q.exec()){
                    while(q.next()){
                        count++;
                    }

                    if(count==1){
                        QMessageBox::information(nullptr,"Bienvenue","Salut @"+po+", Heureux de vous revoir...\n- - - - - Passez de bons moments... - - - - -");
                        q.prepare("INSERT INTO Administrateurs(Pseudo, Password) VALUES(:pseud,:pass)");
                        q.bindValue(":pseud",po);
                        q.bindValue(":pass",por);
                        if(!q.exec()){
                            QMessageBox::critical(nullptr,"Erreur lors de l'Insertion des données",q.lastError().text());
                        }
                        Choix *ch=new Choix;
                        ch->show();
                        this->close();
                    }
                    else if(count<1){
                              QMessageBox::warning(nullptr,"Inscrivez-vous","Vous êtes un nouveau.....\n\n Vous serez redirigé vers le Formulaire d'Inscription pour les Utilisateurs!!\n Dans le cas où vous voudriez être un Admin, demandez au SuperAdmin Apasize!!");
                              Form *form=new Form;
                              form->show();
                              this->close();
                    }
                    ui->pseudo->clear();
                    ui->key->clear();
                }

                else if(!q.exec()){
                    QMessageBox::information(nullptr,"Erreur lors de l'Insertion des données",q.lastError().text());
               }
                     ui->pseudo->clear();
                     ui->key->clear();
                    }
                 }
                else if(but<1){
                    QMessageBox::information(nullptr,"Erreur","Pseudo Inexistant...\n Vous serez redirigé vers le Formulaire d'Inscription pour les Utilisateurs!!\n Dans le cas où vous voudriez être un Admin, demandez au SuperAdmin Apasize!!");
                    Form *form=new Form;
                    form->show();
                    this->close();
                    ui->pseudo->clear();
                    ui->key->clear();
                }

         }
            else{
                QMessageBox::critical(nullptr,"Enregistement",q.lastError().text());
             }

            }
    else{
        QMessageBox::critical(nullptr,"Enregistement","Veuillez remplir les champs");
    }

        }
        else
        {
           QMessageBox::critical(nullptr,"Enregistement","Veuillez remplir les champs");
        }
}

void Formul::on_quit_clicked()
{
    int reponse = QMessageBox::question(nullptr,"Game","Voulez-vous vraiment quitter le Jeu",QMessageBox::Yes|QMessageBox::No);

    if(reponse == QMessageBox::Yes){
        QMessageBox::information(nullptr,"OUPS!!!","Heureux d'avoir pu vous divertir\n\n À la prochaine.....");
        this->close();
    }
    else if(reponse == QMessageBox::No){
        QMessageBox::information(nullptr,"YOUPI!!","Retour au jeu");
    }
}


void Formul::on_pushButton_clicked()
{
    Fenetre *h=new Fenetre;
    h->show();
    this->close();
}

