#include "choice.h"
#include "ui_choice.h"

Choice::Choice(QWidget *parent) :
    QMainWindow(parent),
    ui(new Ui::Choice)
{
    ui->setupUi(this);
}

Choice::~Choice()
{
    delete ui;
}

void Choice::on_inscrire_clicked()
{
    Form * th=new Form;
    th->show();
    this->close();
}


void Choice::on_start_clicked()
{
    Cont * nu=new Cont;
    nu->show();
    this->close();
}


void Choice::on_pushButton_clicked()
{
    Fenetre *ju=new Fenetre;
    ju->show();
    this->close();
}

