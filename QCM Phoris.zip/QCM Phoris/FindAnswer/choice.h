#ifndef CHOICE_H
#define CHOICE_H

#include <QMainWindow>
#include "supuser.h"
#include "fenetre.h"
#include "score.h"
#include "cont.h"
#include "choix.h"
#include "fake.h"
#include "table.h"
#include "finder.h"
#include "form.h"
#include "formul.h"

namespace Ui {
class Choice;
}

class Choice : public QMainWindow
{
    Q_OBJECT

public:
    explicit Choice(QWidget *parent = nullptr);
    ~Choice();

private slots:
    void on_inscrire_clicked();

    void on_start_clicked();

    void on_pushButton_clicked();

private:
    Ui::Choice *ui;
};

#endif // CHOICE_H
