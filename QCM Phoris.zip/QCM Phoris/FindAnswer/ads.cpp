#include "ads.h"
#include "ui_ads.h"
#include <QInputDialog>

Ads::Ads(QWidget *parent) :
    QMainWindow(parent),
    ui(new Ui::Ads)
{
    ui->setupUi(this);

    QString nam="Tbls";
    q.prepare("DROP TABLE IF EXISTS "+nam);
    if(!q.exec()){
        QMessageBox::information(this,"BugZzzz",q.lastError().text());
    }
}

Ads::~Ads()
{
    delete ui;
}

void Ads::on_pushButton_3_clicked()
{
    Table *tble=new Table;
    tble->show();
    this->close();
}


void Ads::on_pushButton_4_clicked()
{
    int count=0;
    input();
    int cout=0;
    k.prepare("SELECT * FROM Tbls");
    if(q.exec()){
        while(q.next()){
            cout++;
        }

        if(cout>=1){
            bool ok=false;
            QString table=QInputDialog::getText(this,"Nom de la Table","Nom de la Table :",QLineEdit::Normal, QString(), &ok);

            if(table.isEmpty()){
                QMessageBox::information(this,"Bug","Renseignez le nom de la table");
            }

            else{
                k.prepare("SELECT * FROM Tbls WHERE Nom=:nam");
                k.bindValue(":nam",table);
                if(k.exec()){
                    while (k.next()) {
                        count++;
                    }

                    if(count>=1){
                        if(ok && !table.isEmpty()){
                            q.prepare("DROP TABLE "+table);
                            if(q.exec()){
                                r.prepare("DELETE FROM Tble WHERE Nomtable=:tabl");
                                r.bindValue(":tabl",table);
                                if(!r.exec()){
                                    QMessageBox::warning(this,"BugZz",q.lastError().text());
                                }
                                QMessageBox::information(this,"No_Bug","- - - - Table "+table+" Supprimée avec Succès!!! - - - -");
                            }
                            else{
                                QMessageBox::warning(this,"BugZzz",q.lastError().text());
                            }
                        }
                        else{
                            QMessageBox::critical(this,"Table","Nom de la Table attendue!");
                        }
                    }

                    else if(count<1){
                        QMessageBox::warning(this,"SuperUser","Vous n'êtes pas autorisé à supprimer cette table ou encore cette table n'existe pas...\n\n- - - - Choisissez un Nom convenable...");
                    }
                }

                else{
                    QMessageBox::warning(this,"Renseignez-nous","Vous n'avez rien choisi...\n\n- - - - Choisissez un Nom convenable...");
                }
            }
        }

        else{
            QMessageBox::information(this,"Rien","Vous n'avez pas de Tables à supprimer...\n- - - - Allez donc en créer... - - - -");
        }
    }
}


void Ads::on_pushButton_2_clicked()
{
    Fenetre *ne=new Fenetre;
    ne->show();
    this->close();

    QString nam="Tbls";
    q.prepare("DROP TABLE "+nam);
    if(!q.exec()){
        QMessageBox::information(this,"BugZzzz",q.lastError().text());
    }
}


void Ads::on_pushButton_5_clicked()
{
    Choix *ch=new Choix;
    ch->show();
    this->hide();

    QString nam="Tbls";
    q.prepare("DROP TABLE "+nam);
    if(!q.exec()){
        QMessageBox::information(this,"BuZzzz",q.lastError().text());
    }
}

void Ads::input()
{
    QString createTable("CREATE TABLE IF NOT EXISTS Tbls(Id INTEGER PRIMARY KEY AUTOINCREMENT, Nom VARCHAR(50))");

    if(!q.exec(createTable))
      {
          QMessageBox::critical(nullptr,"Echec lors de la création de la table",q.lastError().text());
      }

    QSqlQuery q;
    QString recp,rcv;
    recp=("SELECT * FROM Administrateurs");
    q.prepare(recp);
    if(q.exec()){
        QString receive;
        if(q.last()){
            receive = q.value(0).toString();
            rcv=receive;
        }
    }
    else{
        QMessageBox::critical(this,"Enregistement",q.lastError().text());
    }

   r.prepare("SELECT Nomtable FROM Tble WHERE Pseudo=:ap");
   r.bindValue(":ap",rcv);
   if(r.exec()){
       while(r.next()){
           QString u=r.value(0).toString();
            k.prepare("INSERT INTO Tbls(Nom) VALUES(:nam)");
            k.bindValue(":nam",u);
            if(!k.exec()){
                QMessageBox::critical(nullptr,"Erreur lors de l'Insertion des données",q.lastError().text());
            }
       }

       }
}

