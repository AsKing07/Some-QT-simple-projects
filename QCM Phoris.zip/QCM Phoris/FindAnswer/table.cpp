#include "table.h"
#include "ui_table.h"

Table::Table(QWidget *parent) :
    QMainWindow(parent),
    ui(new Ui::Table)
{
    ui->setupUi(this);
}

Table::~Table()
{
    delete ui;
}

void Table::on_pushButton_5_clicked()
{
    QString recp,rcv;
    recp=("SELECT * FROM Administrateurs");
    q.prepare(recp);

    if(q.exec()){
        QString receive;
        if(q.last()){
            receive = q.value(0).toString();
            rcv= q.value(1).toString();
        }

        if(receive=="Apasize" && rcv=="007"){
            Finder *find=new Finder;
            find->show();
            this->close();
        }
        else{
            Ads *ad=new Ads;
            ad->show();
            this->close();
        }
    }

    else{
        QMessageBox::critical(this,"Enregistement",q.lastError().text());
    }
}


void Table::on_pushButton_clicked()
{
    QSqlQuery q;
    nam=ui->name->text();
    at1=ui->att1->text();
    at2=ui->att2->text();
    at3=ui->att3->text();
    at4=ui->att4->text();
    at5=ui->att5->text();

    if(nam.isEmpty()){
        QMessageBox::information(this,"Nom de la Base","Voulez-vous créer une Table sans Nom ??\n- - - - - Entrez un Nom - - - - -");
    }

    else if(!nam.isEmpty() && !at1.isEmpty() && !at2.isEmpty() && at3.isEmpty() && at4.isEmpty() && at5.isEmpty()){
        QString ty=("CREATE TABLE IF NOT EXISTS "+nam+"("+at1+","+at2+")");
        if(!q.exec(ty))
          {
              QMessageBox::critical(this,"Echec lors de la création de la table",q.lastError().text());
          }
        else{
            QMessageBox::information(this,"Down it","- - - - - Table "+nam+", créée avec succès - - - - -");
        }

        ui->name->clear();
        ui->att1->clear();
        ui->att2->clear();

        if(!nam.isEmpty()){
            QString recp,rcv;
            recp=("SELECT * FROM Administrateurs");
            q.prepare(recp);

            if(q.exec()){
                QString receive;
                if(q.last()){
                    receive = q.value(0).toString();
                    rcv=receive;
                }
            }

            else{
                QMessageBox::critical(this,"Enregistement",q.lastError().text());
            }


             q.prepare("INSERT INTO Tble(Pseudo, Nomtable) VALUES(:pseud,:nam)");
             q.bindValue(":pseud",rcv);
             q.bindValue(":nam",nam);
             if(!q.exec()){
                 QMessageBox::critical(nullptr,"Erreur lors de l'Insertion des données",q.lastError().text());
             }
        }
    }

    else if(!nam.isEmpty() && !at1.isEmpty() && !at2.isEmpty() && !at3.isEmpty() && at4.isEmpty() && at5.isEmpty()){
        QString ty=("CREATE TABLE IF NOT EXISTS "+nam+"("+at1+","+at2+","+at3+")");
        if(!q.exec(ty))
          {
              QMessageBox::critical(this,"Echec lors de la création de la table",q.lastError().text());
          }
        else{
            QMessageBox::information(this,"Down it","- - - - - Table "+nam+", créée avec succès - - - - -");
        }

        if(!nam.isEmpty()){
            QString recp,rcv;
            recp=("SELECT * FROM Administrateurs");
            q.prepare(recp);

            if(q.exec()){
                QString receive;
                if(q.last()){
                    receive = q.value(0).toString();
                    rcv=receive;
                }
            }

            else{
                QMessageBox::critical(this,"Enregistement",q.lastError().text());
            }


             q.prepare("INSERT INTO Tble(Pseudo, Nomtable) VALUES(:pseud,:nam)");
             q.bindValue(":pseud",rcv);
             q.bindValue(":nam",nam);
             if(!q.exec()){
                 QMessageBox::critical(nullptr,"Erreur lors de l'Insertion des données",q.lastError().text());
             }
        }

        ui->name->clear();
        ui->att1->clear();
        ui->att2->clear();
        ui->att3->clear();
    }

    else if(!nam.isEmpty() && !at1.isEmpty() && !at2.isEmpty() && !at3.isEmpty() && !at4.isEmpty() && at5.isEmpty()){
        QString ty=("CREATE TABLE IF NOT EXISTS "+nam+"("+at1+","+at2+","+at3+","+at4+")");
        if(!q.exec(ty))
          {
              QMessageBox::critical(this,"Echec lors de la création de la table",q.lastError().text());
          }
        else{
            QMessageBox::information(this,"Down it","- - - - - Table "+nam+", créée avec succès - - - - -");
        }

        if(!nam.isEmpty()){
            QString recp,rcv;
            recp=("SELECT * FROM Administrateurs");
            q.prepare(recp);

            if(q.exec()){
                QString receive;
                if(q.last()){
                    receive = q.value(0).toString();
                    rcv=receive;
                }
            }

            else{
                QMessageBox::critical(this,"Enregistement",q.lastError().text());
            }


             q.prepare("INSERT INTO Tble(Pseudo, Nomtable) VALUES(:pseud,:nam)");
             q.bindValue(":pseud",rcv);
             q.bindValue(":nam",nam);
             if(!q.exec()){
                 QMessageBox::critical(nullptr,"Erreur lors de l'Insertion des données",q.lastError().text());
             }
        }

        ui->name->clear();
        ui->att1->clear();
        ui->att2->clear();
        ui->att3->clear();
        ui->att4->clear();
    }
    else if(!nam.isEmpty() && !at1.isEmpty() && !at2.isEmpty() && !at3.isEmpty() && !at4.isEmpty() && !at5.isEmpty()){
        QString ty=("CREATE TABLE IF NOT EXISTS "+nam+"("+at1+","+at2+","+at3+","+at4+","+at5+")");
        if(!q.exec(ty))
          {
              QMessageBox::critical(this,"Echec lors de la création de la table",q.lastError().text());
          }
        else{
            QMessageBox::information(this,"Down it","- - - - - Table "+nam+", créée avec succès - - - - -");
        }

        if(!nam.isEmpty()){
            QString recp,rcv;
            recp=("SELECT * FROM Administrateurs");
            q.prepare(recp);

            if(q.exec()){
                QString receive;
                if(q.last()){
                    receive = q.value(0).toString();
                    rcv=receive;
                }
            }

            else{
                QMessageBox::critical(this,"Enregistement",q.lastError().text());
            }


             q.prepare("INSERT INTO Tble(Pseudo, Nomtable) VALUES(:pseud,:nam)");
             q.bindValue(":pseud",rcv);
             q.bindValue(":nam",nam);
             if(!q.exec()){
                 QMessageBox::critical(nullptr,"Erreur lors de l'Insertion des données",q.lastError().text());
             }
        }

        ui->name->clear();
        ui->att1->clear();
        ui->att2->clear();
        ui->att3->clear();
        ui->att4->clear();
        ui->att5->clear();
    }
    else{
        QMessageBox::critical(this,"Renseignement","Veuillez renseignez au moins deux attributs et en ordre svp...");
        ui->name->clear();
        ui->att1->clear();
        ui->att2->clear();
        ui->att3->clear();
        ui->att4->clear();
        ui->att5->clear();
    }
}

