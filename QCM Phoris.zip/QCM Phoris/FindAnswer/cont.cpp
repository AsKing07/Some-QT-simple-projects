#include "cont.h"
#include "ui_cont.h"

Cont::Cont(QWidget *parent) :
    QMainWindow(parent),
    ui(new Ui::Cont)
{
    ui->setupUi(this);
}

Cont::~Cont()
{
    delete ui;
}

void Cont::on_pushButton_clicked()
{
    Choice *ui=new Choice;
    ui->show();
    this->close();
}


void Cont::on_quit_clicked()
{
    Fenetre *ny=new Fenetre;
    ny->show();
    this->close();
}


void Cont::on_go_clicked()
{
    int count=0;
    QString po=ui->pseudo->text();
    QString por=ui->key->text();
    if(!ui->pseudo->text().isEmpty()&& !por.isEmpty()){
        QString pd;
        int but=0;
    if(!ui->pseudo->text().isEmpty()){
            q.prepare("SELECT * FROM User WHERE Pseudo=:pseud");
            q.bindValue(":pseud",ui->pseudo->text());
            if(q.exec()){
                while(q.next()){
                    but++;
                }

                if(but==1){
                    if(q.last()){
                        pd = q.value(4).toString();
                    }

                    if(pd!=ui->key->text()){
                        QMessageBox::information(nullptr,"Erreur","Pseudo ou Mot de Passe Incorrect");
                                 ui->pseudo->clear();
                                 ui->key->clear();
                    }

                    else{
                q.prepare("SELECT * FROM User WHERE Pseudo=:pseudonyme AND Password=:code");
                q.bindValue(":pseudonyme",ui->pseudo->text());
                q.bindValue(":code",ui->key->text());

                if(q.exec()){
                    while(q.next()){
                        count++;
                    }

                    if(count==1){
                        SupUser *tu=new SupUser;

                        QMessageBox::information(nullptr,"Nous Revoilà !!!","Quel Plaisir de vous revoir très cher @"+po+"...\n\n- - - - - - - - Flambez les Scores - - - - - - - -");

                            q.prepare("INSERT INTO Use(Pseudo,Password) VALUES(:pseudo,:pass)");
                            q.bindValue(":pseudo",ui->pseudo->text());
                            q.bindValue(":pass",ui->key->text());

                            if(!q.exec()){
                                QMessageBox::information(nullptr,"Erreur lors de l'Insertion des données",q.lastError().text());
                            }

                            tu->show();
                            this->close();
                    }
                    else if(count<1){
                                  QMessageBox::warning(nullptr,"Inscrivez-vous","Vous êtes un nouveau.....\n\n Vous serez redirigé vers le Formulaire d'Inscription !!");
                                  Form *form=new Form;
                                  form->show();
                                  this->close();
                   }
                }
                else{
                         QMessageBox::critical(nullptr,"Echec lors du parcours des requêtes ",q.lastError().text());
                }
                  }

                }
               else if(but<1){
                QMessageBox::warning(nullptr,"Inscrivez-vous","Vous êtes un nouveau.....\n\n Vous serez redirigé vers le Formulaire d'Inscription !!");
                Form *form=new Form;
                form->show();
                this->close();
               }
         }

    else{
       QMessageBox::critical(nullptr,"Enregistement",q.lastError().text());
    }

  }

        }
        else
        {
           QMessageBox::critical(nullptr,"Enregistement","Veuillez remplir les champs");
        }

}

