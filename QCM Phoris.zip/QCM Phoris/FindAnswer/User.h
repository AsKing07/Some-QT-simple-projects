#ifndef USER_H
#define USER_H

#include <QSqlDatabase>
#include<QSqlError>
#include<QMessageBox>
#include<QSqlQuery>

inline bool connexionBD()
{
    QSqlDatabase db = QSqlDatabase::addDatabase("QSQLITE");
    db.setDatabaseName("finder.db");
         if(!db.open())
         {
          return false ;
         }
         else
         {
          return true ;
         }
}
#endif // USER_H
