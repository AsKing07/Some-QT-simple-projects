#ifndef ADMIN_H
#define ADMIN_H

#include <QMainWindow>
#include <QSqlQuery>
#include <QSqlError>
#include "supuser.h"
#include "fenetre.h"
#include "score.h"
#include "choix.h"
#include "fake.h"
#include "table.h"
#include "finder.h"
#include "form.h"
#include "formul.h"
#include "ads.h"
#include "choice.h"
#include "cont.h"



namespace Ui {
class Admin;
}

class Admin : public QMainWindow
{
    Q_OBJECT

public:
    explicit Admin(QWidget *parent = nullptr);
    ~Admin();

private slots:
    void on_save_clicked();

    void on_delete_2_clicked();

    void on_delet_all_clicked();

    void on_finish_clicked();

    void on_pushButton_5_clicked();

private:
    Ui::Admin *ui;
    QString categorie,un,deux,trois,quatre,cinq;
    QString ans1,ans2,ans3,ans4,ans5;
    QSqlQuery q;
};

#endif // ADMIN_H
