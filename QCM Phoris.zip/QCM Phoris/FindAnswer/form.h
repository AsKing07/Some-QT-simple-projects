#ifndef FORM_H
#define FORM_H

#include <QMainWindow>
#include "admin.h"
#include "fenetre.h"
#include "choice.h"
#include "cont.h"
#include "score.h"
#include "ads.h"
#include "choix.h"
#include "fake.h"
#include "table.h"
#include "finder.h"
#include "formul.h"

namespace Ui {
class Form;
}

class Form : public QMainWindow
{
    Q_OBJECT

public:
    explicit Form(QWidget *parent = nullptr);
    ~Form();

private slots:
    void on_go_clicked();

    void on_pushButton_clicked();

    void on_quit_clicked();

private:
    Ui::Form *ui;
    QSqlQuery q;
};

#endif // FORM_H
