#include "finder.h"
#include "ui_finder.h"
#include <QInputDialog>

Finder::Finder(QWidget *parent) :
    QMainWindow(parent),
    ui(new Ui::Finder)
{
    ui->setupUi(this);
}

Finder::~Finder()
{
    delete ui;
}

void Finder::on_pushButton_3_clicked()
{
    Table *tble=new Table;
    tble->show();
    this->close();
}

void Finder::on_pushButton_2_clicked()
{
    Fenetre *ne=new Fenetre;
    ne->show();
    this->close();
}


void Finder::on_pushButton_5_clicked()
{
    Choix *ch=new Choix;
    ch->show();
    this->hide();
}


void Finder::on_pushButton_4_clicked()
{

            bool ok=false;
            QString table=QInputDialog::getText(this,"Nom de la Table","Nom de la Table :",QLineEdit::Normal, QString(), &ok);

            if(table.isEmpty()){
                QMessageBox::information(this,"Bug","Renseignez le nom de la table");
            }

            else{
                        if(ok && !table.isEmpty()){
                            q.prepare("DROP TABLE "+table);
                            if(q.exec()){
                                r.prepare("DELETE FROM Tble WHERE Nomtable=:tabl");
                                r.bindValue(":tabl",table);
                                if(!r.exec()){
                                    QMessageBox::warning(this,"BugZz",q.lastError().text());
                                }
                                QMessageBox::information(this,"No_Bug","- - - - Table "+table+" Supprimée avec Succès!!! - - - -");
                            }
                            else{
                                QMessageBox::warning(this,"BugZzz","Cette Table n'existe sûrement pas...");
                            }
                        }
                        else{
                            QMessageBox::critical(this,"Table","Nom de la Table attendue!");
                        }
            }
}


void Finder::on_pushButton_6_clicked()
{
    bool ok=false;
    QString pseudo=QInputDialog::getText(this,"Nom de l'Admin","Renseignez son Pseudo :",QLineEdit::Normal, QString(), &ok);
    QString pass=QInputDialog::getText(this,"Sécurité","Vous n'avez droit qu'à un Essai alors soyez attentifs.\n\n- - - - Renseignez son mot de Passe :",QLineEdit::Password, QString(), &ok);
    if(ok && !pseudo.isEmpty() && !pass.isEmpty()){
        q.prepare("INSERT INTO Admin(Pseudo, Password) VALUES(:pseud,:pass)");
            q.bindValue(":pseud",pseudo);
            q.bindValue(":pass",pass);
            if(!q.exec()){
                QMessageBox::critical(nullptr,"Erreur lors de l'Insertion des données",q.lastError().text());
            }
    }
    else{
        QMessageBox::warning(nullptr,"Renseignez-Nous","Veuillez remplir tous les deux champs si vous tenez à créer un nouvel Admin...");
    }
}

