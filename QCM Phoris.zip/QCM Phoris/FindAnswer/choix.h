#ifndef CHOIX_H
#define CHOIX_H

#include <QMainWindow>
#include "supuser.h"
#include "fenetre.h"
#include "score.h"
#include "choice.h"
#include "cont.h"
#include "fake.h"
#include "table.h"
#include "finder.h"
#include "form.h"
#include "formul.h"
#include "ads.h"

namespace Ui {
class Choix;
}

class Choix : public QMainWindow
{
    Q_OBJECT

public:
    explicit Choix(QWidget *parent = nullptr);
    ~Choix();

private slots:
    void on_pushButton_clicked();

    void on_pushButton_5_clicked();

    void on_pushButton_3_clicked();

    void on_pushButton_2_clicked();

    void on_pushButton_4_clicked();

private:
    Ui::Choix *ui;
    QSqlQuery q;
};

#endif // CHOIX_H
