#include "choix.h"
#include "ui_choix.h"

Choix::Choix(QWidget *parent) :
    QMainWindow(parent),
    ui(new Ui::Choix)
{
    ui->setupUi(this);
}

Choix::~Choix()
{
    delete ui;
}

void Choix::on_pushButton_clicked()
{
    Admin *Super=new Admin;
    Super->show();
    this->close();
}


void Choix::on_pushButton_5_clicked()
{
    Formul *nel=new Formul;
    nel->show();
    this->close();
}


void Choix::on_pushButton_3_clicked()
{
    QString recp,rcv;
    recp=("SELECT * FROM Administrateurs");
    q.prepare(recp);

    if(q.exec()){
        QString receive;
        if(q.last()){
            receive = q.value(0).toString();
            rcv= q.value(1).toString();
        }

        if(receive=="Apasize" && rcv=="007"){
            Finder *find=new Finder;
            find->show();
            this->close();
        }
        else{
            Ads *ad=new Ads;
            ad->show();
            this->close();
        }
    }

    else{
        QMessageBox::critical(this,"Enregistement",q.lastError().text());
    }
}


void Choix::on_pushButton_2_clicked()
{
    Fake *fk=new Fake;
    fk->show();
    this->close();
}


void Choix::on_pushButton_4_clicked()
{
    Fenetre *ft=new Fenetre;
    ft->show();
    this->close();
}

