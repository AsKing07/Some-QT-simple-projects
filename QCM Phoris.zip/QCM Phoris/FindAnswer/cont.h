#ifndef CONT_H
#define CONT_H

#include <QMainWindow>
#include "supuser.h"
#include "fenetre.h"
#include "score.h"
#include "choix.h"
#include "fake.h"
#include "table.h"
#include "finder.h"
#include "form.h"
#include "formul.h"
#include "ads.h"
#include "choice.h"

namespace Ui {
class Cont;
}

class Cont : public QMainWindow
{
    Q_OBJECT

public:
    explicit Cont(QWidget *parent = nullptr);
    ~Cont();

private slots:
    void on_pushButton_clicked();

    void on_quit_clicked();

    void on_go_clicked();

private:
    Ui::Cont *ui;
    QSqlQuery q;
};

#endif // CONT_H
