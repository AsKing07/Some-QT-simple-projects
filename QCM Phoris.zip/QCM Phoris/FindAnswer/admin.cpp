#include "admin.h"
#include "ui_admin.h"

Admin::Admin(QWidget *parent) :
    QMainWindow(parent),
    ui(new Ui::Admin)
{
    ui->setupUi(this);
    on_delet_all_clicked();
}

Admin::~Admin()
{
    delete ui;
}

void Admin::on_save_clicked()
{
    categorie=ui->cat->text();
    un=ui->quiz1->text();
    deux=ui->quiz2->text();
    trois=ui->quiz3->text();
    quatre=ui->quiz4->text();
    cinq=ui->quiz5->text();

    ans1=ui->ans1->text();
    ans2=ui->ans2->text();
    ans3=ui->ans3->text();
    ans4=ui->ans4->text();
    ans5=ui->ans5->text();

    if(!categorie.isEmpty()&& !un.isEmpty()&& !deux.isEmpty()&& !trois.isEmpty()&& !quatre.isEmpty()&& !cinq.isEmpty()&&
       !ans1.isEmpty()&& !ans2.isEmpty()&& !ans3.isEmpty()&& !ans4.isEmpty()&& !ans5.isEmpty()){

        q.prepare("INSERT INTO QCM(Categorie, Quiz, Ans)  VALUES(:cat, :quiz, :ans)");
        q.bindValue(":cat",categorie);
        q.bindValue(":quiz",un);
        q.bindValue(":ans",ans1);

        if(!q.exec()){
            QMessageBox::information(this,"Erreur lors de l'Insertion des données", q.lastError().text());
        }

        q.prepare("INSERT INTO QCM(Categorie, Quiz, Ans)  VALUES(:cat, :quiz, :ans)");
        q.bindValue(":cat",categorie);
        q.bindValue(":quiz",deux);
        q.bindValue(":ans",ans2);

        if(!q.exec()){
            QMessageBox::information(this,"Erreur lors de l'Insertion des données", q.lastError().text());
        }

        q.prepare("INSERT INTO QCM(Categorie, Quiz, Ans)  VALUES(:cat, :quiz, :ans)");
        q.bindValue(":cat",categorie);
        q.bindValue(":quiz",trois);
        q.bindValue(":ans",ans3);

        if(!q.exec()){
            QMessageBox::information(this,"Erreur lors de l'Insertion des données", q.lastError().text());
        }

        q.prepare("INSERT INTO QCM(Categorie, Quiz, Ans)  VALUES(:cat, :quiz, :ans)");
        q.bindValue(":cat",categorie);
        q.bindValue(":quiz",quatre);
        q.bindValue(":ans",ans4);

        if(!q.exec()){
            QMessageBox::information(this,"Erreur lors de l'Insertion des données", q.lastError().text());
        }

        q.prepare("INSERT INTO QCM(Categorie, Quiz, Ans)  VALUES(:cat, :quiz, :ans)");
        q.bindValue(":cat",categorie);
        q.bindValue(":quiz",cinq);
        q.bindValue(":ans",ans5);

        if(!q.exec()){
            QMessageBox::information(this,"Erreur lors de l'Insertion des données", q.lastError().text());
        }

        q.prepare("INSERT INTO Cat(Categorie)  VALUES(:cat)");
        q.bindValue(":cat",categorie);

        if(!q.exec()){
            QMessageBox::information(this,"Erreur lors de l'Insertion des données", q.lastError().text());
        }

        on_delet_all_clicked();
    }
    else{
        QMessageBox::critical(this,"INSERTION","Veuillez remplir tous les champs...\n Je vous Sais Créatif");
    }

}


void Admin::on_delete_2_clicked()
{
    categorie=ui->cat->text();
    un=ui->quiz1->text();
    deux=ui->quiz2->text();
    trois=ui->quiz3->text();
    quatre=ui->quiz4->text();
    cinq=ui->quiz5->text();

    ans1=ui->ans1->text();
    ans2=ui->ans2->text();
    ans3=ui->ans3->text();
    ans4=ui->ans4->text();
    ans5=ui->ans5->text();

    if(!categorie.isEmpty()&& un.isEmpty()){
        ui->cat->clear();
    }

    if(!categorie.isEmpty()&& !un.isEmpty()&& ans1.isEmpty()){
        ui->quiz1->clear();
    }
    if(!categorie.isEmpty()&& !un.isEmpty()&& !ans1.isEmpty()&& deux.isEmpty()){
        ui->ans1->clear();
    }
    if(!categorie.isEmpty()&& !un.isEmpty()&& !ans1.isEmpty()&& !deux.isEmpty()&& ans2.isEmpty()){
        ui->quiz2->clear();
    }
    if(!categorie.isEmpty()&& !un.isEmpty()&& !ans1.isEmpty()&& !deux.isEmpty()&& !ans2.isEmpty()&& trois.isEmpty()){
        ui->ans2->clear();
    }
    if(!categorie.isEmpty()&& !un.isEmpty()&& !ans1.isEmpty()&& !deux.isEmpty()&& !ans2.isEmpty()&& !trois.isEmpty()&& ans3.isEmpty()){
        ui->quiz3->clear();
    }
    if(!categorie.isEmpty()&& !un.isEmpty()&& !ans1.isEmpty()&& !deux.isEmpty()&& !ans2.isEmpty()&& !trois.isEmpty()&& !ans3.isEmpty()&& quatre.isEmpty()){
        ui->ans3->clear();
    }
    if(!categorie.isEmpty()&& !un.isEmpty()&& !ans1.isEmpty()&& !deux.isEmpty()&& !ans2.isEmpty()&& !trois.isEmpty()&& !ans3.isEmpty()&& !quatre.isEmpty()&& ans4.isEmpty()){
        ui->quiz4->clear();
    }
    if(!categorie.isEmpty()&& !un.isEmpty()&& !ans1.isEmpty()&& !deux.isEmpty()&& !ans2.isEmpty()&& !trois.isEmpty()&& !ans3.isEmpty()&& !quatre.isEmpty()&& !ans4.isEmpty()&& cinq.isEmpty()){
        ui->ans4->clear();
    }
    if(!categorie.isEmpty()&& !un.isEmpty()&& !ans1.isEmpty()&& !deux.isEmpty()&& !ans2.isEmpty()&& !trois.isEmpty()&& !ans3.isEmpty()&& !quatre.isEmpty()&& !ans4.isEmpty()&& !cinq.isEmpty()&& ans5.isEmpty()){
        ui->quiz5->clear();
    }
    if(!categorie.isEmpty()&& !un.isEmpty()&& !ans1.isEmpty()&& !deux.isEmpty()&& !ans2.isEmpty()&& !trois.isEmpty()&& !ans3.isEmpty()&& !quatre.isEmpty()&& !ans4.isEmpty()&& !cinq.isEmpty()&& !ans5.isEmpty()){
        ui->ans5->clear();
    }
}


void Admin::on_delet_all_clicked()
{
    ui->cat->clear();
    ui->quiz1->clear();
    ui->ans1->clear();
    ui->quiz2->clear();
    ui->ans2->clear();
    ui->quiz3->clear();
    ui->ans3->clear();
    ui->quiz4->clear();
    ui->ans4->clear();
    ui->quiz5->clear();
    ui->ans5->clear();
}


void Admin::on_finish_clicked()
{
    on_delet_all_clicked();
    Choix *neuf=new Choix;
    neuf->show();
    this->close();
}


void Admin::on_pushButton_5_clicked()
{
    Choix *ch=new Choix;
    ch->show();
    this->hide();
}

