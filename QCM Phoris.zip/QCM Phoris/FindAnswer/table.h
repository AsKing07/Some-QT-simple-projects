#ifndef TABLE_H
#define TABLE_H

#include <QMainWindow>
#include "supuser.h"
#include "fenetre.h"
#include "score.h"
#include "choix.h"
#include "fake.h"
#include "admin.h"
#include "finder.h"
#include "form.h"
#include "ads.h"
#include "choice.h"
#include "formul.h"
#include "cont.h"

namespace Ui {
class Table;
}

class Table : public QMainWindow
{
    Q_OBJECT

public:
    explicit Table(QWidget *parent = nullptr);
    ~Table();

private slots:
    void on_pushButton_5_clicked();

    void on_pushButton_clicked();

private:
    Ui::Table *ui;
    QString nam,at1,at2,at3,at4,at5;
    QSqlQuery q;
};

#endif // TABLE_H
