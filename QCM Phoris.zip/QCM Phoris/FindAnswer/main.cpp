#include "fenetre.h"
#include "User.h"
#include <QApplication>
#include <QSqlQuery>
#include <QTranslator>
#include <QLocale>
#include <QLibraryInfo>

int main(int argc, char *argv[])
{
    QApplication a(argc, argv);

    QString locale = QLocale::system().name().section('_', 0, 0);
    QTranslator translator;
    translator.load(QString("qt_")+locale, QLibraryInfo::location(QLibraryInfo::TranslationsPath));
    a.installTranslator(&translator);

    Fenetre w;

    if(!connexionBD())
    {
        return 1 ;
    }

    QSqlQuery q;
   QString createTable1("CREATE TABLE IF NOT EXISTS QCM(Id INTEGER PRIMARY KEY AUTOINCREMENT, Categorie VARCHAR(100), Quiz VARCHAR(500), Ans VARCHAR(500))");
   QString createTable2("CREATE TABLE IF NOT EXISTS Fak_in(Id INTEGER PRIMARY KEY AUTOINCREMENT, Categorie VARCHAR(100), fake1 VARCHAR(500), fake2 VARCHAR(500), fake3 VARCHAR(500))");
   QString createTable3("CREATE TABLE IF NOT EXISTS Admin(Id INTEGER PRIMARY KEY AUTOINCREMENT, Pseudo VARCHAR(50), Password VARCHAR(50))");
   QString createTable4("CREATE TABLE IF NOT EXISTS Administrateurs(Pseudo VARCHAR(50), Password VARCHAR(50))");
   QString createTable5("CREATE TABLE IF NOT EXISTS User(Id INTEGER PRIMARY KEY AUTOINCREMENT, Pseudo VARCHAR(50), Nom VARCHAR(50), Prenoms VARCHAR(50), Password VARCHAR(50))");
   QString createTable6("CREATE TABLE IF NOT EXISTS Use(Id INTEGER PRIMARY KEY AUTOINCREMENT, Pseudo VARCHAR(50), Password VARCHAR(50))");
   QString createTable7("CREATE TABLE IF NOT EXISTS Tble(Pseudo VARCHAR(50), Nomtable VARCHAR(50))");
   QString createTable("CREATE TABLE IF NOT EXISTS Categorie(Pseudo VARCHAR(50), Categorie VARCHAR(50))");
   QString createTable8("CREATE TABLE IF NOT EXISTS Cat(Id INTEGER PRIMARY KEY AUTOINCREMENT, Categorie VARCHAR(50))");
   QString createTable9("CREATE TABLE IF NOT EXISTS Point(Categorie VARCHAR(50), Pseudo VARCHAR(50), Pts INT(05))");



    if(!q.exec(createTable1))
      {
          QMessageBox::critical(nullptr,"Echec lors de la création de la table",q.lastError().text());
          return 1;
      }
    if(!q.exec(createTable2))
      {
          QMessageBox::critical(nullptr,"Echec lors de la création de la table",q.lastError().text());
          return 1;
      }
    if(!q.exec(createTable3))
      {
          QMessageBox::critical(nullptr,"Echec lors de la création de la table",q.lastError().text());
          return 1;
      }
    if(!q.exec(createTable4))
      {
          QMessageBox::critical(nullptr,"Echec lors de la création de la table",q.lastError().text());
          return 1;
      }
    if(!q.exec(createTable5))
      {
          QMessageBox::critical(nullptr,"Echec lors de la création de la table",q.lastError().text());
          return 1;
      }
    if(!q.exec(createTable6))
      {
          QMessageBox::critical(nullptr,"Echec lors de la création de la table",q.lastError().text());
          return 1;
      }

    if(!q.exec(createTable7))
      {
          QMessageBox::critical(nullptr,"Echec lors de la création de la table",q.lastError().text());
          return 1;
      }

    if(!q.exec(createTable))
      {
          QMessageBox::critical(nullptr,"Echec lors de la création de la table",q.lastError().text());
          return 1;
      }

    if(!q.exec(createTable8))
      {
          QMessageBox::critical(nullptr,"Echec lors de la création de la table",q.lastError().text());
          return 1;
      }

    if(!q.exec(createTable9))
      {
          QMessageBox::critical(nullptr,"Echec lors de la création de la table",q.lastError().text());
          return 1;
      }

   /* q.prepare("INSERT INTO Admin(Pseudo, Password) VALUES(:pseud,:pass)");
    q.bindValue(":pseud","Apasize");
    q.bindValue(":pass","007");
    if(!q.exec()){
        QMessageBox::critical(nullptr,"Erreur lors de l'Insertion des données",q.lastError().text());
    }*/

    w.show();
    return a.exec();
}
