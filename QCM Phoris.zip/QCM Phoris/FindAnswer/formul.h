#ifndef FORMUL_H
#define FORMUL_H

#include <QMainWindow>
#include "admin.h"
#include "fenetre.h"
#include "score.h"
#include "choice.h"
#include "cont.h"
#include "ads.h"
#include "choix.h"
#include "fake.h"
#include "table.h"
#include "finder.h"
#include "form.h"

namespace Ui {
class Formul;
}

class Formul : public QMainWindow
{
    Q_OBJECT

public:
    explicit Formul(QWidget *parent = nullptr);
    ~Formul();

private slots:
    void on_go_clicked();

    void on_quit_clicked();

    void on_pushButton_clicked();

private:
    Ui::Formul *ui;
    QSqlQuery q;
};

#endif // FORMUL_H
