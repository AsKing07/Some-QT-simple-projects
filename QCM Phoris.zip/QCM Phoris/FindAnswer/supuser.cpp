#include "supuser.h"
#include "ui_supuser.h"

SupUser::SupUser(QWidget *parent) :
    QMainWindow(parent),
    ui(new Ui::SupUser)
{
    ui->setupUi(this);

    QString nam="Part";
    q.prepare("DROP TABLE IF EXISTS "+nam);
    if(!q.exec()){
        QMessageBox::information(this,"BugZzzz",q.lastError().text());
    }


    bool ok=false;
    QString cat;
    int i=0;
    do{
          cat=QInputDialog::getText(this,"Catégorie","Quelle Catégorie voulez-vous jouez :",QLineEdit::Normal, QString(), &ok);
          k.prepare("SELECT * FROM Cat WHERE Categorie=:cat GROUP BY Categorie");
          k.bindValue(":cat",cat);
          if(k.exec()){
              while (k.next()) {
                  i++;
              }

              if(i<1){
                  QMessageBox::critical(this,"Catégorie non trouvée","Cette catégorie n'existe pas...");
              }
          }
          else{
               QMessageBox::critical(this,"Erreur lors de l'execution",q.lastError().text());
          }
    }while (cat.isEmpty() || i<1);


    if(ok && !cat.isEmpty()){
                QString recp,rcv;
                recp=("SELECT * FROM Use");
                r.prepare(recp);

                if(r.exec()){
                    QString receive;
                    if(r.last()){
                        receive = r.value(1).toString();
                        rcv=receive;
                    }
                }

                else{
                    QMessageBox::critical(this,"Enregistement",q.lastError().text());
                }

                 q.prepare("INSERT INTO Categorie(Pseudo, Categorie) VALUES(:pseud,:cat)");
                 q.bindValue(":pseud",rcv);
                 q.bindValue(":cat",cat);
                 if(!q.exec()){
                     QMessageBox::critical(nullptr,"Erreur lors de l'Insertion des données",q.lastError().text());
                 }


                ui->cate->setText(cat);

                temps1 =new QTimer(this);
                temps1->start(1000);

                compte = new QTimer(this);
                compte->start(1000);
                connect(compte, SIGNAL(timeout()), this, SLOT(desc()));

                rec();
                recp=("SELECT * FROM Use");
                r.prepare(recp);

                if(r.exec()){
                    QString receive;
                    if(r.last()){
                        receive = r.value(1).toString();
                        rcv=receive;
                    }
                }

                else{
                    QMessageBox::critical(this,"Enregistement",q.lastError().text());
                }
                ui->un->setText("@"+rcv);

                q.prepare("SELECT * FROM Part");
                if(q.exec() && q.next()){
                        uno=q.value(2).toString();
                        dos=q.value(3).toString();
                        tres=q.value(4).toString();
                        quatro=q.value(5).toString();
                        cinquo=q.value(6).toString();

                        ui->quiz->setText(uno);

                       ope1=QRandomGenerator::global()->bounded(1,4);

                       if(ope1==1){

                           ui->ans1->setText(dos);
                           ui->ans2->setText(tres);
                           ui->ans3->setText(quatro);
                           ui->ans4->setText(cinquo);
                       }

                       else if(ope1==2){

                           ui->ans1->setText(cinquo);
                           ui->ans2->setText(dos);
                           ui->ans3->setText(tres);
                           ui->ans4->setText(quatro);
                       }

                       else if(ope1==3){

                           ui->ans1->setText(quatro);
                           ui->ans2->setText(cinquo);
                           ui->ans3->setText(dos);
                           ui->ans4->setText(tres);
                       }

                       else if(ope1==4){

                           ui->ans1->setText(tres);
                           ui->ans2->setText(quatro);
                           ui->ans3->setText(cinquo);
                           ui->ans4->setText(dos);
                       }


                }
                else{
                    QMessageBox::critical(this,"Enregistement",q.lastError().text());
                }

                numpartie();


    }

   /* else{
        QMessageBox::information(this,"Que jouez-vous ??","Catégorie attendue!!!");
        this->close();
        Cont *ru=new Cont;
        ru->show();
        this->hide();
    }*/



}

SupUser::~SupUser()
{
    delete ui;
}

void SupUser::desc()
{
    QString g=ui->quatre->text();
    decompte=decompte-1;
    ui->time->setText(QString::number(decompte));
    if(decompte==0){
        next();
    }
    if(g=="FIN DE LA PARTIE"){
        ui->time->setText("00");
    }

}

void SupUser::time1()
{
    tempsact += 1;
    if(tempsact==5 && tour==1){
        on_passed_clicked();
    }
    else if(tempsact==3){
         on_passed_clicked();
    }

}

void SupUser::reset()
{
    connect(temps1, SIGNAL(timeout()), this, SLOT(time1()));
    temps1=0;
    tempsact=0;
    connect(temps1, SIGNAL(timeout()), this, SLOT(time1()));
}

void SupUser::reset2()
{
    compte=0;
    decompte=15;
    ui->time->setText(QString::number(decompte));
    connect(compte, SIGNAL(timeout()), this, SLOT(desc()));
}

void SupUser::numpartie()
{
    tour++;

    if(tour==1){
        ui->quatre->setText("1ère Opération");
    }

    else if(tour==2){
        ui->quatre->setText("2ème Opération");
    }

    else if(tour==3){
        ui->quatre->setText("3ème Opération");
    }

    else if(tour==4){
        ui->quatre->setText("4ème Opération");
    }

    else if(tour==5){
        ui->quatre->setText("5ème Opération");
    }

    else if(tour==6){
        ui->quatre->setText("6ème Opération");
    }

    else if(tour==7){
        ui->quatre->setText("7ème Opération");
    }

    else if(tour==8){
        ui->quatre->setText("8ème Opération");
    }

    else if(tour==9){
        ui->quatre->setText("9ème Opération");
    }

    else if(tour==10){
        ui->quatre->setText("10ème Opération");
    }

    else{

        tour=0;
        numpartie();
        reset2();
        fin();
        QMessageBox::information(this,"FIN","- - - - - -Vous avez atteint la fin de la partie- - - - - -");
        Score *rt=new Score;
        rt->show();
        this->close();

        uno=ui->cate->text();
        dos=ui->un->text();
        tres=ui->trois->text();

         q.prepare("INSERT INTO Point(Categorie, Pseudo, Pts) VALUES(:cat,:pseud,:pts)");
         q.bindValue(":cat",uno);
         q.bindValue(":pseud",dos);
         q.bindValue(":pts",tres);
         if(!q.exec()){
             QMessageBox::critical(nullptr,"Erreur lors de l'Insertion des données",q.lastError().text());
         }
    }
}

void SupUser::point()
{
    tmaker=ui->time->text().toInt();

    scorer=ui->trois->text().toInt();
    scorer=scorer+10;
    ui->trois->setText(QString::number(scorer));

    /*if(tmaker>=20){
        scorer=ui->trois->text().toInt();
        scorer=scorer+10;
        ui->trois->setText(QString::number(scorer));
    }

    else if(tmaker>=10 && tmaker<20){
        scorer=ui->trois->text().toInt();
        scorer=scorer+5;
        ui->trois->setText(QString::number(scorer));
    }

    else if(tmaker<10){
        scorer=ui->trois->text().toInt();
        scorer=scorer+2;
        ui->trois->setText(QString::number(scorer));
    }*/
}

void SupUser::on_passed_clicked()
{
    next();
    numpartie();
    reset2();
}

void SupUser::on_quitter_clicked()
{
    fin();
    int reponse = QMessageBox::question(this,"Game","Voulez-vous vraiment quitter la partie",QMessageBox::Yes|QMessageBox::No);

    if(reponse == QMessageBox::Yes){
        int re=QMessageBox::question(this,"Attention!!","Retour à l'accueil...",QMessageBox::Yes|QMessageBox::No);
        if(re == QMessageBox::Yes){
            Fenetre *nouveau=new Fenetre;
            nouveau->show();
            this->hide();
        }
        else if(re == QMessageBox::No){
            this->close();
        }
    }
    else if(reponse == QMessageBox::No){
        QMessageBox::information(this,"YOUPI!!","Retour au jeu");
        tour=0;
        reset2();
        numpartie();
    }
}


void SupUser::on_pushButton_5_clicked()
{
    fin();
    QMessageBox::information(this,"Retour à la case départ","Vous serez redirigé vers la page de Choix!!!");
    Choice *yu=new Choice;
    yu->show();
    this->close();
}




void SupUser::on_ans1_clicked()
{

    uno=ui->ans1->text();
    cinquo=q.value(3).toString();

    if(cinquo==uno){
        point();
        reset2();
        numpartie();
        next();
    }
    else{
        numpartie();
        reset2();
        next();
    }
}


void SupUser::on_ans2_clicked()
{

    dos=ui->ans2->text();
    cinquo=q.value(3).toString();

    if(cinquo==dos){
        point();
        reset2();
        numpartie();
        next();
    }
    else{
        numpartie();
        reset2();
        next();
    }
}


void SupUser::on_ans3_clicked()
{

    tres=ui->ans3->text();
    cinquo=q.value(3).toString();

    if(cinquo==tres){
        point();
        reset2();
        numpartie();
        next();
    }
    else{
        numpartie();
        reset2();
        next();
    }
}


void SupUser::on_ans4_clicked()
{

    quatro=ui->ans4->text();
    cinquo=q.value(3).toString();

    if(cinquo==quatro){
        point();
        reset2();
        numpartie();
        next();
    }
    else{
        numpartie();
        reset2();
        next();
    }
}

void SupUser::fin()
{
    ui->quatre->setText("FIN DE LA PARTIE");
    ui->time->setText("00");

}

void SupUser::rec()
{

    QString recp,rcv;
    recp=("SELECT * FROM Categorie");
    r.prepare(recp);

    if(r.exec()){
        QString receive;
        if(r.last()){
            receive = r.value(1).toString();
            rcv=receive;
        }
    }

    else{
        QMessageBox::critical(this,"Enregistement",q.lastError().text());
    }

    int i=0;
    QString createTable("CREATE TABLE IF NOT EXISTS Part(Id INTEGER PRIMARY KEY AUTOINCREMENT, Categorie VARCHAR(100), Quiz VARCHAR(500), Ans VARCHAR(500), fake1 VARCHAR(500), fake2 VARCHAR(500), fake3 VARCHAR(500))");

    if(!q.exec(createTable))
      {
          QMessageBox::critical(nullptr,"Echec lors de la création de la table",q.lastError().text());
      }

    QString Categorie=rcv;
    if(!Categorie.isEmpty()){
        r.prepare("SELECT * FROM QCM WHERE Categorie=:cat");
        r.bindValue(":cat",Categorie);
        k.prepare("SELECT * FROM Fak_in WHERE Categorie=:cat");
        k.bindValue(":cat",Categorie);

        if(r.exec() && k.exec()){
            while (r.next() && k.next()) {
                i++;
                if(i<12){
                    uno=r.value(2).toString();
                    dos=r.value(3).toString();
                    tres=k.value(2).toString();
                    quatro=k.value(3).toString();
                    cinquo=k.value(4).toString();

                        q.prepare("INSERT INTO Part(Categorie, Quiz, Ans, fake1, fake2, fake3) VALUES(:cat,:quiz,:ans,:fk1,:fk2,:fk3)");
                        q.bindValue(":cat",Categorie);
                        q.bindValue(":quiz",uno);
                        q.bindValue(":ans",dos);
                        q.bindValue(":fk1",tres);
                        q.bindValue(":fk2",quatro);
                        q.bindValue(":fk3",cinquo);

                        if(!q.exec()){
                            QMessageBox::critical(this,"Enregistement",q.lastError().text());
                        }
                }
            }
        }
        else{
            QMessageBox::critical(this,"Enregistement",q.lastError().text());
        }
    }
}


void SupUser::next()
{
    if(q.next()){
        uno=q.value(2).toString();
        dos=q.value(3).toString();
        tres=q.value(4).toString();
        quatro=q.value(5).toString();
        cinquo=q.value(6).toString();

        ui->quiz->setText(uno);

        ope1=QRandomGenerator::global()->bounded(1,4);

        if(ope1==1){

            ui->ans1->setText(dos);
            ui->ans2->setText(tres);
            ui->ans3->setText(quatro);
            ui->ans4->setText(cinquo);
        }

        else if(ope1==2){

            ui->ans1->setText(cinquo);
            ui->ans2->setText(dos);
            ui->ans3->setText(tres);
            ui->ans4->setText(quatro);
        }

        else if(ope1==3){

            ui->ans1->setText(quatro);
            ui->ans2->setText(cinquo);
            ui->ans3->setText(dos);
            ui->ans4->setText(tres);
        }

        else if(ope1==4){

            ui->ans1->setText(tres);
            ui->ans2->setText(quatro);
            ui->ans3->setText(cinquo);
            ui->ans4->setText(dos);
        }
    }
    else{
        QMessageBox::critical(this,"Erreur",q.lastError().text());
    }

}


void SupUser::on_effacer_clicked()
{
    QMessageBox::information(this,"Paresseux","Réfléchis mieux...\n- - - - Tu trouveras si tu fermes les yeux deux secondes!!!");
}

