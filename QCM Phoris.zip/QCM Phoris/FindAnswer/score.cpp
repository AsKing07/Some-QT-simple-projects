#include "score.h"
#include "ui_score.h"

Score::Score(QWidget *parent) :
    QMainWindow(parent),
    ui(new Ui::Score)
{
    ui->setupUi(this);

    QString recp,rcv,receive;
    recp=("SELECT * FROM Point");
    q.prepare(recp);

    if(q.exec()){
        if(q.last()){
            receive = "@"+q.value(1).toString();
            rcv= q.value(2).toString();
        }
    }

    else{
        QMessageBox::critical(this,"Enregistement",q.lastError().text());
    }

    ui->pseudo->setText(receive);
    ui->point->setText(rcv);

}

Score::~Score()
{
    delete ui;
}

void Score::on_pushButton_2_clicked()
{
    int reponse = QMessageBox::question(this,"Game","Voulez-vous vraiment quitter le Jeu",QMessageBox::Yes|QMessageBox::No);

    if(reponse == QMessageBox::Yes){
        QMessageBox::information(this,"OUPS!!!","Heureux d'avoir pu vous divertir\n\n À la prochaine.....");
        this->hide();
    }
    else if(reponse == QMessageBox::No){
        QMessageBox::information(this,"YOUPI!!","Retour au jeu");
    }
}


void Score::on_pushButton_clicked()
{
    int fin= QMessageBox::question(this,"PROPOSITION","- - - - - - Voulez-vous continuer ?? - - - - - - ",QMessageBox::Yes|QMessageBox::No);

    if(fin == QMessageBox::Yes){
        QMessageBox::information(this,"YOUPI!!","Jouons une nouvelle Partie");
        SupUser *niv=new SupUser;
        niv->show();
        this->close();
    }
    else if(fin == QMessageBox::No){
        Fenetre *yu=new Fenetre;
        yu->show();
        this->close();
    }
}

