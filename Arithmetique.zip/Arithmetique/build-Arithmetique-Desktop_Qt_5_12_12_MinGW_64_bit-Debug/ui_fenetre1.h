/********************************************************************************
** Form generated from reading UI file 'fenetre1.ui'
**
** Created by: Qt User Interface Compiler version 5.12.12
**
** WARNING! All changes made in this file will be lost when recompiling UI file!
********************************************************************************/

#ifndef UI_FENETRE1_H
#define UI_FENETRE1_H

#include <QtCore/QVariant>
#include <QtWidgets/QApplication>
#include <QtWidgets/QComboBox>
#include <QtWidgets/QDialog>
#include <QtWidgets/QLabel>
#include <QtWidgets/QPushButton>

QT_BEGIN_NAMESPACE

class Ui_Fenetre1
{
public:
    QPushButton *pushButton;
    QLabel *label;
    QComboBox *comboBox;

    void setupUi(QDialog *Fenetre1)
    {
        if (Fenetre1->objectName().isEmpty())
            Fenetre1->setObjectName(QString::fromUtf8("Fenetre1"));
        Fenetre1->resize(571, 294);
        pushButton = new QPushButton(Fenetre1);
        pushButton->setObjectName(QString::fromUtf8("pushButton"));
        pushButton->setGeometry(QRect(250, 220, 75, 23));
        label = new QLabel(Fenetre1);
        label->setObjectName(QString::fromUtf8("label"));
        label->setGeometry(QRect(50, 20, 521, 51));
        comboBox = new QComboBox(Fenetre1);
        comboBox->setObjectName(QString::fromUtf8("comboBox"));
        comboBox->setGeometry(QRect(180, 90, 141, 41));

        retranslateUi(Fenetre1);

        QMetaObject::connectSlotsByName(Fenetre1);
    } // setupUi

    void retranslateUi(QDialog *Fenetre1)
    {
        Fenetre1->setWindowTitle(QApplication::translate("Fenetre1", "Dialog", nullptr));
        pushButton->setText(QApplication::translate("Fenetre1", "Start", nullptr));
        label->setText(QApplication::translate("Fenetre1", "Salut joueur ! Bienvenue dans notre jeu d'arithm\303\251tique! Veuillez choisir le niveau que vous souhaitez jouer.", nullptr));
    } // retranslateUi

};

namespace Ui {
    class Fenetre1: public Ui_Fenetre1 {};
} // namespace Ui

QT_END_NAMESPACE

#endif // UI_FENETRE1_H
