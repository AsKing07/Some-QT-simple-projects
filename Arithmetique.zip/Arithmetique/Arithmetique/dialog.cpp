#include "dialog.h"
#include "ui_dialog.h"
//#include "fenetre1.h"
#include<QDebug>
#include<QPixmap>
#include <QMessageBox>

Dialog::Dialog(QWidget *parent)
    : QDialog(parent)
    , ui(new Ui::Dialog)
{
    ui->setupUi(this);
    QPixmap pix("D:/PICTURES/images (5).jpeg");
    int w = ui->label_4->width();
    int h = ui->label_4->height();
    ui->label_4->setPixmap(pix.scaled(w,h,Qt::KeepAspectRatio));
    mydb=QSqlDatabase::addDatabase("QSQLITE");
    /*QSqlDatabase mydb = QSqlDatabase::addDatabase("QPSQL");
    mydb.setHostName("acidalia");
    mydb.setDatabaseName("customdb");
    mydb.setUserName("mojito");
    mydb.setPassword("J0a1m8");
    bool ok = mydb.open();*/

    mydb.setDatabaseName("C:/Users/Renaud/Desktop/Mes_programmes_Qt/Arithmetiquedatabase.db");

    if(!mydb.open())
        ui->label->setText("Failed to open the database");
    else
        ui->label->setText("Connected...");

    if(!querry.exec("CREATE TABLE if not exists Joueur (username Varchar(255), scoreNiveau1 int, scoreNiveau2 int,  scoreNiveau3 int)"))
        QMessageBox::critical(this,"table",querry.lastError().text());
    querry.prepare("INSERT INTO Joueur (username, scoreNiveau1, scoreNiveau2, scoreNiveau3) VALUES(:username, :scoreNiveau1, :scoreNiveau2, :scoreNiveau3)") ;

    querry.bindValue(":username", "username");
    querry.bindValue(":scoreNiveau1", "scoreNiveau1");
    querry.bindValue(":scoreNiveau2", "scoreNiveau2");
    querry.bindValue(":scoreNiveau3", "scoreNiveau3");
    querry.exec();

}

Dialog::~Dialog()
{
    delete ui;
}


void Dialog::on_pushButton_clicked()
{
  /*Fenetre1 fenetre1;
  fenetre1.setModal(true);
  fenetre1.exec();*/
  hide();
  fenetre1=new Fenetre1(this);
  fenetre1->show();

  QString username,password;
  username=ui->lineEdit_username->text();
  password=ui->lineEdit_password->text();

  if(!mydb.isOpen()){
      qDebug()<<"Failed to open the database";
      return;
   }
  QSqlQuery qry;
  qry.prepare("select*from emploieeinfo where username='"+username+"'and password='"+password+"'");
  if(qry.exec()){
      int count=0;
      while(qry.next())
         {
         count++;
         }
      if(count==1){
          ui->label->setText("username and password is correct");
          this->hide();
          EmployeeInfo emploieeinfo;
          emploieeinfo.setModal(true);
          emploieeinfo.exec();
      }
      if(count>1)
          ui->label->setText("Duplicate username and password");
      if(count<1)
          ui->label->setText("username and password is not correct");
  }

}
