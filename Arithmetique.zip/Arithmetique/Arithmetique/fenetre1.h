#ifndef FENETRE1_H
#define FENETRE1_H
#include"employeeinfo.h"
#include <QDialog>

namespace Ui {
class Fenetre1;
}

class Fenetre1 : public QDialog
{
    Q_OBJECT

public:
    explicit Fenetre1(QWidget *parent = nullptr);
    ~Fenetre1();

private slots:
    void on_comboBox_activated(const QString &arg1);

    void on_pushButton_clicked();

private:
    Ui::Fenetre1 *ui;
    EmployeeInfo*emploieeinfo;
};

#endif // FENETRE1_H
