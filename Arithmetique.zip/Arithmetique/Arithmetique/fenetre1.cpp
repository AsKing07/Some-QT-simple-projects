#include "fenetre1.h"
#include "ui_fenetre1.h"
//#include"employeeinfo.h"

Fenetre1::Fenetre1(QWidget *parent) :
    QDialog(parent),
    ui(new Ui::Fenetre1)
{
    ui->setupUi(this);
    ui->comboBox->addItem("Niveaux");
    ui->comboBox->addItem("Facile");
    ui->comboBox->addItem("Normale");
    ui->comboBox->addItem("Difficile");
}

Fenetre1::~Fenetre1()
{
    delete ui;
}

void Fenetre1::on_comboBox_activated(const QString &)
{

}

void Fenetre1::on_pushButton_clicked()
{
    /*EmployeeInfo emploieeinfo;
    emploieeinfo.setModal(true);
    emploieeinfo.exec();*/
    hide();
    emploieeinfo=new EmployeeInfo(this);
    emploieeinfo->show();
}

