#include "dialog.h"
#include "fenetre1.h"
#include <QApplication>
#include"employeeinfo.h"

int main(int argc, char *argv[])
{
    QApplication a(argc, argv);
    Dialog w;
    Fenetre1 fenetre1;
    w.show();
    return a.exec();
}
