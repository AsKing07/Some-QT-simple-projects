#ifndef HISTORIQUE_H
#define HISTORIQUE_H

#include <QDialog>

namespace Ui {
class historique;
}

class historique : public QDialog
{
    Q_OBJECT

public:
    explicit historique(QWidget *parent = nullptr);
    ~historique();
    void affiche_combo();

private slots:
    void on_back_clicked();

    void on_comboBox_currentTextChanged(const QString &arg1);

private:
    Ui::historique *ui;
};

#endif // HISTORIQUE_H
