#include "accueil.h"
#include "ui_accueil.h"
#include "employes.h"
#include "client.h"
#include "locationvoiture.h"
#include "voitures.h"
#include "etatparc.h"
#include "location_voiture.h"
#include "historique.h"

Accueil::Accueil(QWidget *parent) :
    QDialog(parent),
    ui(new Ui::Accueil)
{
    ui->setupUi(this);
}

Accueil::~Accueil()
{
    delete ui;
}

void Accueil::on_bouton_employe_clicked()
{
    Location_Voiture conn;
    conn.connClose();
    this -> hide();
    Employes emp;
    emp.exec();
}


void Accueil::on_bouton_client_clicked()
{
    Location_Voiture conn;
    conn.connClose();
    this -> hide();
    Client cli;
    cli.exec();
}


void Accueil::on_bouton_voiture_clicked()
{
    Location_Voiture conn;
    conn.connClose();
    this -> hide();
    Voitures voi;
    voi.exec();
}



void Accueil::on_bouton_location_clicked()
{
    Location_Voiture conn;
    conn.connClose();
    this -> hide();
    Locationvoiture location;
    location.exec();
}



void Accueil::on_bouton_parc_clicked()
{
    Location_Voiture conn;
    conn.connClose();

    this -> hide();
    Etatparc etat;
    etat.exec();
}




void Accueil::on_bouton_Se_Deconnecter_clicked()
{
    Location_Voiture log;
    log.connClose();
    this -> hide();    
    log.exec();

}


void Accueil::on_bouton_historique_clicked()
{
    Location_Voiture conn;
    conn.connClose();

    this -> hide();
    historique history;
    history.exec();
}

