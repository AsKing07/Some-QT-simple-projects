#include "ui_employes.h"
#include "accueil.h"
#include "employes.h"
#include <QInputDialog>
//#include "location_voiture.h"



Employes::Employes(QWidget *parent) :
    QDialog(parent),
    ui(new Ui::Employes)
{
    Location_Voiture conn;
    ui->setupUi(this);

    if(!conn.connOpen())
    {
        ui ->statut_2 -> setText("Echec de la connexion");

    }
    else
    {
        ui -> statut_2 -> setText("Connecté...");
        conn.connClose();
    }
}

Employes::~Employes()
{
    delete ui;
}

void Employes::on_button_sauvegarde_clicked()
{
    Location_Voiture conn;
    QString username,password,nom,prenom,id;
    id = ui -> line_id_employe -> text();
    nom = ui -> line_nom_employe -> text();
    prenom = ui -> line_prenom_employe -> text();
    username = ui -> line_username_employe -> text();
    password = nom+"default";

    if(nom.isEmpty()||prenom.isEmpty()|| username.isEmpty() || password.isEmpty())
    {
        ui -> statut_2 -> setText("Vous devez obligatoirement remplir tous les champs");
        QMessageBox::critical(this,"Remplissage","Vous devez obligatoirement remplir tous les champs pour les sauvegardes");
    }
    else
    {
        if(!conn.connOpen())
        {
           qDebug() << "Failed to open the database";
           return;
        }
        else
        {
            conn.connOpen();
            QSqlQuery qry;
            qry.prepare("insert into Employes (id_empl,nom,prenom,username,password) "
                        "values ('"+id+"','"+nom+"','"+prenom+"','"+username+"','"+password+"')");
            if(qry.exec())
            {
                QMessageBox::critical(this,"Enregistrement","Données sauvegardées");
                conn.connClose();
            }
            else
            {
                QMessageBox::critical(this,"error::",qry.lastError().text());
                conn.connClose();
            }
        }


    }
}


void Employes::on_button_modification_clicked()
{
    Location_Voiture conn;
    QString id,username,password,nom,prenom;
    id = ui -> line_id_employe -> text();
    nom = ui -> line_nom_employe -> text();
    prenom = ui -> line_prenom_employe -> text();
    username = ui -> line_username_employe -> text();

    if(nom.isEmpty()||prenom.isEmpty()|| username.isEmpty())
    {
        ui -> statut_2 -> setText("Vous devez obligatoirement remplir tous les champs");
        QMessageBox::critical(this,"Remplissage","Vous devez obligatoirement remplir tous les champs");
    }
    else
    {
        if(!conn.connOpen())
        {
           qDebug() << "Failed to open the database";
           return;
        }
        conn.connOpen();
        int count(0);
        QSqlQuery qry1,qry2;
        qry2.prepare("select * from Employes");

        if(qry2.exec())
        {
            while(qry2.next())
            {
                if(qry2.value(0).toString()==id)
                {
                    count++;
                    if(qry2.value(4).toString()==nom+"default")
                    {
                        QMessageBox::critical(this,"Compte vulnérable","Vous utilisez toujours le mot de passe par défaut, Veuillez le changer");
                        password = QInputDialog::getText(this,"Ancien Mot de Passe","Entrer un nouveau mot de passe");
                    }
                    else
                    {
                        password = qry2.value(4).toString();
                    }
                }
            }

        }
        qry1.prepare("update Employes set nom='"+nom+"',prenom='"+prenom+"',username='"+username+"',password='"+password+"' where id_empl='"+id+"'");
        if(count<1)
        {
            QMessageBox::critical(this,"Erreur","Cet employé n'est pas dans la base de donnée");
        }
        else if(count == 1)
        {

            if(qry1.exec())
            {
                QMessageBox::critical(this,"Modification","Vos données ont été modifiées!");
                conn.connClose();
            }
            else
            {
                QMessageBox::critical(this,"Erreur",qry1.lastError().text());
                conn.connClose();
            }
        }

    }
}

void Employes::on_button_suppression_clicked()
{
    Location_Voiture conn;
    QString id;
    id = ui -> line_id_employe -> text();
    if(id.isEmpty())
    {
        ui -> statut_2 -> setText("Vous devez obligatoirement remplir le champ id, le reste n'est pas obligatoire pour la suppression");
        QMessageBox::critical(this,"Suppression","Vous devez obligatoirement remplir le champ id, le reste n'est pas obligatoire pour la suppression");
    }
    else
    {
        if(!conn.connOpen())
        {
           qDebug() << "Failed to open the database";
           return;
        }
        conn.connOpen();
        QSqlQuery qry;
        qry.prepare("delete from Employes where id_empl='"+id+"'");
        if(qry.exec())
        {
            QMessageBox::critical(this,"Suppression","Données suppriméés");
            conn.connClose();
        }
        else
        {
            QMessageBox::critical(this,"error::",qry.lastError().text());
            conn.connClose();
        }
    }
}


void Employes::on_pushButton_clicked()
{
    Location_Voiture conn;
    conn.connClose();
    this -> hide();
    Accueil retour;
    retour.exec();
}


void Employes::on_buton_charger_table_clicked()
{
    QSqlQueryModel *model = new QSqlQueryModel;
    Location_Voiture conn;

    conn.connOpen();
    QSqlQuery *qry = new QSqlQuery(conn.mydb);

    qry -> prepare("select id_empl,nom,prenom,username from Employes");
    qry -> exec();
    model -> setQuery(*qry);
    ui -> tableView ->setModel(model);
    conn.connClose();
    qDebug() << (model -> rowCount());


}


void Employes::on_tableView_activated(const QModelIndex &index)
{
    QString val = ui -> tableView -> model() -> data(index).toString();
    Location_Voiture conn;
    if(!conn.connOpen())
    {
        qDebug() << "Echec de la connexion";
        return;
    }
    conn.connOpen();
    QSqlQuery qry1;
    qry1.prepare("select id_empl,nom,prenom,username from Employes where id_empl='"+val+"'");

    if(qry1.exec())
    {
        while(qry1.next())
        {

                    ui -> line_id_employe -> setText(qry1.value(0).toString());
                    ui -> line_nom_employe -> setText(qry1.value(1).toString());
                    ui -> line_prenom_employe -> setText(qry1.value(2).toString());
                    ui -> line_username_employe -> setText(qry1.value(3).toString());

        }
        conn.connClose();
    }
    else
    {
        QMessageBox::critical(this,"erreur",qry1.lastError().text());
    }
}

