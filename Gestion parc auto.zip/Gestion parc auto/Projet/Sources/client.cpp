#include "client.h"
#include "ui_client.h"
#include "accueil.h"
#include <QDateTime>
//#include "location_voiture.h"


Client::Client(QWidget *parent) :
    QDialog(parent),
    ui(new Ui::Client)
{

    ui->setupUi(this);
    Location_Voiture conn;
    if(!conn.connOpen())
    {
        qDebug() << ("Echec de la connexion à la base");
    }
    else
    {
        ui -> statut_client -> setText("Connectée");
        conn.connClose();
    }
}

Client::~Client()
{
    delete ui;
}

void Client::on_pushButton_clicked()
{
    Location_Voiture conn;
    conn.connClose();
    this -> hide();
    Accueil retour;
    retour.exec();
}


void Client::on_button_sauvegarde_client_clicked()
{
    QString id,nom,prenom,age,sexe,date_t,time_t;
    QDate date = QDate::currentDate();
    date_t = date.toString("dd/MM/yyyy");
    QTime time = QTime::currentTime();
    time_t = time.toString("hh : mm : ss");

    id = ui -> line_client_id -> text();
    nom = ui -> line_nom_client -> text();
    prenom = ui -> line_prenom_client -> text();
    age = ui-> line_age_client -> text();
    sexe = ui -> comboBox -> currentText();
    Location_Voiture conn;
    if(id.isEmpty()||nom.isEmpty()||prenom.isEmpty()||age.isEmpty())
    {
        ui -> statut_client -> setText("Vous devez obligatoirement remplir tous les champs");
        QMessageBox::critical(this,"Remplissage","Vous devez obligatoirement remplir tous les champs pour les sauvegardes");
    }
    else if(age.toInt()<18)
    {
        QMessageBox::critical(this,"Remplissage","Vous n'avez pas encore 18ans");
    }
    else
    {
        if(!conn.connOpen())
        {
            qDebug() << "Echec lors de la connexion...";
            return;
        }
        else
        {
            conn.connOpen();
            QSqlQuery qry;
            qry.prepare("insert into Clients (id_client,nom,prenom,age,date_inscr,sexe,heure_inscr) "
                        "values ('"+id+"','"+nom+"','"+prenom+"','"+age+"','"+date_t+"','"+sexe+"','"+time_t+"')");
            if(qry.exec())
            {
                QMessageBox::critical(this,"Sauvegarde","Vos données ont été sauvegardé");
                conn.connClose();
            }
            else
            {
                QMessageBox::critical(this,"Erreur",qry.lastError().text());
                conn.connClose();
            }
        }
    }




}
void Client::on_pushButton_2_clicked()
{
    QSqlQueryModel *model = new QSqlQueryModel;
    Location_Voiture conn;

    conn.connOpen();
    QSqlQuery *qry = new QSqlQuery(conn.mydb);

    qry -> prepare("select * from Clients");
    qry -> exec();
    model -> setQuery(*qry);
    ui -> tableView_client ->setModel(model);
    conn.connClose();
    qDebug() << (model -> rowCount());
}

void Client::on_button_modification_client_clicked()
{
    QString id,nom,prenom,age,date,sexe;
    id = ui -> line_client_id -> text();
    nom = ui -> line_nom_client -> text();
    prenom = ui -> line_prenom_client -> text();
    age = ui-> line_age_client -> text();
    sexe = ui -> comboBox -> currentText();
    Location_Voiture conn;
    if(id.isEmpty()||nom.isEmpty()||prenom.isEmpty()||age.isEmpty()|| sexe.isEmpty())
    {
        ui -> statut_client -> setText("Vous devez obligatoirement remplir tous les champs");
        QMessageBox::critical(this,"Remplissage","Vous devez obligatoirement remplir tous les champs pour les modifications");
    }
    else
    {
        if(!conn.connOpen())
        {
            qDebug() << "Echec lors de la connexion...";
            return;
        }
        else
        {

            conn.connOpen();
            int count=0;
            QSqlQuery qry1,qry2;
            qry1.prepare("update Clients set id_client='"+id+"',nom='"+nom+"',prenom='"+prenom+"',age='"+age+"',sexe='"+sexe+"' where id_client='"+id+"'");
            qry2.prepare("select * from Clients");

            if(qry2.exec())
            {
                while(qry2.next())
                {
                    if(qry2.value(0).toString()==id)
                    {
                        count++;
                    }
                }

            }
            if(count<1)
            {
                QMessageBox::critical(this,"Erreur","Ce client n'est pas dans la base de donnée");
            }
            else if(count == 1)
            {
                if(qry1.exec())
                {
                    QMessageBox::critical(this,"Modification","Vos données ont été modifiées!");
                    conn.connClose();
                }
                else
                {
                    QMessageBox::critical(this,"Erreur",qry1.lastError().text());
                    conn.connClose();
                }
            }



        }
    }
}


void Client::on_button_suppression_client_clicked()
{
    Location_Voiture conn;
    QString id,nom,prenom,age,sexe;
    id = ui -> line_client_id-> text();
    nom = ui -> line_nom_client -> text();
    prenom = ui -> line_prenom_client -> text();
    age = ui-> line_age_client -> text();
    sexe = ui -> comboBox -> currentText();
    if(id.isEmpty())
    {
        ui -> statut_client -> setText("Vous devez obligatoirement remplir le champ id, le reste n'est pas obligatoire pour la suppression");
        QMessageBox::critical(this,"Suppression","Vous devez obligatoirement remplir le champ id, le reste n'est pas obligatoire pour la suppression");
    }
    else if(!nom.isEmpty()||!prenom.isEmpty()||!age.isEmpty())
    {
        QMessageBox::critical(this,"Suppression","Seul l'id est demandé pour la suppression");
    }
    else
    {
        if(!conn.connOpen())
        {
           qDebug() << "Failed to open the database";
           return;
        }
        conn.connOpen();
        QSqlQuery qry;
        qry.prepare("delete from Clients where id_client='"+id+"'");
        if(qry.exec())
        {
            QMessageBox::critical(this,"Suppression","Données suppriméés");
            conn.connClose();
        }
        else
        {
            QMessageBox::critical(this,"error::",qry.lastError().text());
            conn.connClose();
        }
    }
}



void Client::on_tableView_client_activated(const QModelIndex &index)
{
    QString val = ui -> tableView_client -> model() -> data(index).toString();
    Location_Voiture conn;
    if(!conn.connOpen())
    {
        qDebug() << "Echec de la connexion";
        return;
    }
    conn.connOpen();
    QSqlQuery qry;
    qry.prepare("select * from Clients where id_client='"+val+"'");

    if(qry.exec())
    {
        while(qry.next())
        {
            ui -> line_client_id -> setText(qry.value(0).toString());
            ui -> line_nom_client -> setText(qry.value(1).toString());
            ui -> line_prenom_client -> setText(qry.value(2).toString());
            ui -> line_age_client -> setText(qry.value(3).toString());
            ui -> comboBox -> setCurrentText(qry.value(5).toString());
        }
        conn.connClose();
    }
    else
    {
        QMessageBox::critical(this,"erreur",qry.lastError().text());
    }

}

