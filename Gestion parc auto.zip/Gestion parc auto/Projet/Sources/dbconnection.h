#ifndef DBCONNECTION_H
#define DBCONNECTION_H

#include "location_voiture.h"

void Location_Voiture::connClose()
{
    mydb.close();
    mydb.removeDatabase(QSqlDatabase::defaultConnection);
}
bool Location_Voiture::connOpen()

{
    mydb = QSqlDatabase::addDatabase("QSQLITE");
    mydb.setDatabaseName("../Build/projet_5.db");

    if(!mydb.open())
    {
        qDebug() << "Echec de la connexion";
        return false;
    }
    else
    {
        qDebug() << "Connecté...";
        return true;
    }
}



#endif // DBCONNECTION_H
