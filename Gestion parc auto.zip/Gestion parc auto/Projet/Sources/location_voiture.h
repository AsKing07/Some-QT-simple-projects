#ifndef LOCATION_VOITURE_H
#define LOCATION_VOITURE_H

#include <QDialog>
#include <QtSql>
#include <QtDebug>
#include <QFileInfo>

namespace Ui {
class Location_Voiture;
}

class Location_Voiture : public QDialog
{
    Q_OBJECT

public: //fonction pour la base de donnée début
    QSqlDatabase mydb;
    void connClose();
    bool connOpen();


//fonction pour la base donnée fin

private slots:
    void on_log_bot_2_clicked();

public:
    explicit Location_Voiture(QWidget *parent = nullptr);
    ~Location_Voiture();

private:
    Ui::Location_Voiture *ui;
};

#endif // LOCATION_VOITURE_H
