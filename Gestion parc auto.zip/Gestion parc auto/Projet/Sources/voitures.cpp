#include "voitures.h"
#include "ui_voitures.h"
#include "accueil.h"
//#include "location_voiture.h"

Voitures::Voitures(QWidget *parent) :
    QDialog(parent),
    ui(new Ui::Voitures)
{
    ui->setupUi(this);
}

Voitures::~Voitures()
{
    delete ui;
}

void Voitures::on_pushButton_clicked()
{
    Location_Voiture conn;
    conn.connClose();
    this -> hide();
    Accueil retour;
    retour.exec();
}


void Voitures::on_Button_save_car_clicked()
{
    Location_Voiture conn;
    QString marque,modele,no_imma,kilometrage,id,etat;
    id = ui -> Edit_id -> text();
    marque = ui -> Edit_marque -> text();
    modele = ui -> Edit_modele-> text();
    no_imma = ui -> Edit_no_Immatriculation -> text();
    kilometrage = ui -> Edit_Kilometrage -> text();
    if(marque.isEmpty()||modele.isEmpty()|| no_imma.isEmpty() || kilometrage.isEmpty())
    {
        ui -> status_voiture -> setText("Vous devez obligatoirement remplir tous les champs");
        QMessageBox::critical(this,"Remplissage","Vous devez obligatoirement remplir tous les champs pour les sauvegardes");
    }
    else
    {
        if(!conn.connOpen())
        {
           qDebug() << "Failed to open the database";
           return;
        }
        else
        {
            conn.connOpen();
            QSqlQuery qry;
            qry.prepare("insert into Voitures (id,marque,modele,no_imma,kilometrage,etat) "
                        "values ('"+id+"','"+marque+"','"+modele+"','"+no_imma+"','"+kilometrage+"','Disponible')");
            if(qry.exec())
            {
                QMessageBox::critical(this,"Enregistrement","Données sauvegardées");
                conn.connClose();
            }
            else
            {
                QMessageBox::critical(this,"error::",qry.lastError().text());
                conn.connClose();
            }
        }


    }
}




void Voitures::on_Button_edit_car_clicked()
{
    Location_Voiture conn;
    QString marque,modele,no_imma,kilometrage,id,etat;
    id = ui -> Edit_id -> text();
    marque = ui -> Edit_marque -> text();
    modele = ui -> Edit_modele-> text();
    no_imma = ui -> Edit_no_Immatriculation -> text();
    kilometrage = ui -> Edit_Kilometrage -> text();
    if(marque.isEmpty()||modele.isEmpty()|| no_imma.isEmpty() || kilometrage.isEmpty()|| id.isEmpty())
    {
        ui -> status_voiture -> setText("Vous devez obligatoirement remplir tous les champs");
        QMessageBox::critical(this,"Remplissage","Vous devez obligatoirement remplir tous les champs");
    }
    else
    {
        if(!conn.connOpen())
        {
           qDebug() << "Failed to open the database";
           return;
        }
        int count(0);
        conn.connOpen();
        QSqlQuery qry1,qry2;
        qry1.prepare("update Voitures set marque='"+marque+"',modele='"+modele+"',no_imma='"+no_imma+"',kilometrage='"+kilometrage+"' where id='"+id+"'");
        qry2.prepare("select * from Clients");

        if(qry2.exec())
        {
            while(qry2.next())
            {
                if(qry2.value(0).toString()==id)
                {
                    count++;
                }
            }

        }
        if(count<1)
        {
            QMessageBox::critical(this,"Erreur","Cette voiture n'est pas dans la base de donnée");
        }
        else if(count == 1)
        {
            if(qry1.exec())
            {
                QMessageBox::critical(this,"Modification","Vos données ont été modifiées!");
                conn.connClose();
            }
            else
            {
                QMessageBox::critical(this,"Erreur",qry1.lastError().text());
                conn.connClose();
            }
        }

    }
}



void Voitures::on_Button_remove_car_clicked()
{
    Location_Voiture conn;
    QString id;
    id = ui -> Edit_id -> text();
    if(id.isEmpty())
    {
        ui -> status_voiture -> setText("Vous devez obligatoirement remplir le champ id, le reste n'est pas obligatoire pour la suppression");
        QMessageBox::critical(this,"Suppression","Vous devez obligatoirement remplir le champ id, le reste n'est pas obligatoire pour la suppression");
    }
    else
    {
        if(!conn.connOpen())
        {
           qDebug() << "Failed to open the database";
           return;
        }
        conn.connOpen();
        QSqlQuery qry;
        qry.prepare("delete from Voitures where id='"+id+"'");
        if(qry.exec())
        {
            QMessageBox::critical(this,"Suppression","Données suppriméés");
            conn.connClose();
        }
        else
        {
            QMessageBox::critical(this,"error::",qry.lastError().text());
            conn.connClose();
        }
    }

}



void Voitures::on_Button_save_car_2_clicked()
{
    QSqlQueryModel *model = new QSqlQueryModel;
    Location_Voiture conn;
    conn.connOpen();
    QSqlQuery *qry = new QSqlQuery(conn.mydb);

    qry -> prepare("select * from Voitures");
    qry -> exec();
    model -> setQuery(*qry);
    ui -> tableVoiture_view ->setModel(model);
    conn.connClose();
    qDebug() << (model -> rowCount());

}

