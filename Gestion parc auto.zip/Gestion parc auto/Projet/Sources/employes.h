#ifndef EMPLOYES_H
#define EMPLOYES_H

#include <QDialog>


namespace Ui {
class Employes;
}

class Employes : public QDialog
{
    Q_OBJECT

public:
    explicit Employes(QWidget *parent = nullptr);
    ~Employes();

private slots:
    void on_button_sauvegarde_clicked();

    void on_button_modification_clicked();

    void on_button_suppression_clicked();

    void on_pushButton_clicked();

    void on_buton_charger_table_clicked();

    void on_tableView_activated(const QModelIndex &index);


private:
    Ui::Employes *ui;
};

#endif // EMPLOYES_H
