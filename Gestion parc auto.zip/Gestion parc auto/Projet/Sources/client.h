#ifndef CLIENT_H
#define CLIENT_H

#include <QDialog>

namespace Ui {
class Client;
}

class Client : public QDialog
{
    Q_OBJECT

public:
    explicit Client(QWidget *parent = nullptr);
    ~Client();

private slots:
    void on_pushButton_clicked();

    void on_button_sauvegarde_client_clicked();

    void on_pushButton_2_clicked();

    void on_button_modification_client_clicked();

    void on_button_suppression_client_clicked();

    void on_tableView_client_activated(const QModelIndex &index);

private:
    Ui::Client *ui;
};

#endif // CLIENT_H
