#include "locationvoiture.h"
#include "ui_locationvoiture.h"
#include "accueil.h"
#include "location_voiture.h"
#include <QDateTime>

Locationvoiture::Locationvoiture(QWidget *parent) :
    QDialog(parent),
    ui(new Ui::Locationvoiture)
{
    Location_Voiture conn;
    ui->setupUi(this);
    QDate date = QDate::currentDate();
    ui -> dateEdit -> setDate(date);
    this->afficher_combo();
    if(!conn.connOpen())
    {
        qDebug() << "Echec de la connection";
    }
    else
    {
        ui -> statuts_location -> setText("Connecté...");
    }
}

Locationvoiture::~Locationvoiture()
{
    delete ui;
}

void Locationvoiture::on_pushButton_clicked()
{
    Location_Voiture conn;
    conn.connClose();
    this -> hide();
    Accueil retour;
    retour.exec();
}


void Locationvoiture::on_button_afficher_clicked()
{
    QSqlQueryModel *model = new QSqlQueryModel;
    Location_Voiture conn;
    conn.connOpen();
    QSqlQuery *qry = new  QSqlQuery(conn.mydb);

    qry -> prepare("select * from Voitures where etat='Disponible'");
    qry -> exec();
    model -> setQuery(*qry);
    ui -> tableView_voiture_dispo -> setModel(model);
    conn.connClose();
    qDebug() << (model->rowCount());
}

void Locationvoiture::afficher_combo()
{
    Location_Voiture conn;
    QSqlQueryModel *modele1 = new QSqlQueryModel();
    QSqlQueryModel *modele2 = new QSqlQueryModel();
    QSqlQueryModel *modele3 = new QSqlQueryModel();

    conn.connOpen();

    QSqlQuery *qry_v=new QSqlQuery(conn.mydb),*qry_c=new QSqlQuery(conn.mydb),*qry_e=new QSqlQuery(conn.mydb);
    qry_v->prepare("select id from Voitures where etat='Disponible'");
    qry_c->prepare("select id_client from Clients");
    qry_e->prepare("select id_empl from Employes");

    qry_v->exec();
    modele1->setQuery(*qry_v);
    qry_c->exec();
    modele2->setQuery(*qry_c);
    qry_e->exec();
    modele3->setQuery(*qry_e);


    ui -> com_id_v -> setModel(modele1);
    ui -> com_id_c -> setModel(modele2);
    ui -> com_id_e -> setModel(modele3);



}


void Locationvoiture::on_buton_louer_clicked()
{

    QString id_v,id_cl,id_empl,date_loc,date_ret,time_text;
    id_v = ui -> com_id_v -> currentText();
    id_cl = ui ->com_id_c -> currentText();
    id_empl = ui -> com_id_e->currentText();
    date_ret = ui -> dateEdit -> text();

    QDate date = QDate::currentDate();
    date_loc = date.toString("dd/MM/yyyy");

}




void Locationvoiture::on_verification_clicked()
{
    Location_Voiture conn;
    QSqlQueryModel *modele4 = new QSqlQueryModel();
    QSqlQueryModel *modele5 = new QSqlQueryModel();
    QSqlQueryModel *modele6 = new QSqlQueryModel();
    QString v1,c1,e1;
    v1 = ui -> com_id_v -> currentText();
    c1 = ui -> com_id_c -> currentText();
    e1 = ui -> com_id_e -> currentText();

    conn.connOpen();

    QSqlQuery *qry_v1=new QSqlQuery(conn.mydb),*qry_c1=new QSqlQuery(conn.mydb),*qry_e1=new QSqlQuery(conn.mydb);
    qry_v1->prepare("select * from Voitures where id='"+v1+"'");
    qry_c1->prepare("select * from Clients where id_client='"+c1+"'");
    qry_e1->prepare("select id_empl,nom,prenom,username,password from Employes where id_empl='"+e1+"'");

    qry_v1->exec();
    modele4->setQuery(*qry_v1);
    qry_c1->exec();
    modele5->setQuery(*qry_c1);
    qry_e1->exec();
    modele6->setQuery(*qry_e1);

    ui -> tableView -> setModel(modele4);
    ui -> tableView_2 -> setModel(modele6);
    ui -> tableView_3 -> setModel(modele5);




}


void Locationvoiture::on_bouton_louer_clicked()
{
    Location_Voiture conn;
    QString v1,c1,e1,dat_fin,date_deb;
    v1 = ui -> com_id_v -> currentText();
    c1 = ui -> com_id_c -> currentText();
    e1 = ui -> com_id_e -> currentText();
    dat_fin = ui -> dateEdit -> text();
    date_deb = QDate::currentDate().toString("dd/MM/yyyy");
    if(dat_fin.isEmpty())
    {
        ui -> statuts_location -> setText("Vous devez obligatoirement remplir tous les champs");
        QMessageBox::critical(this,"Remplissage","Vous devez obligatoirement remplir ce champs pour les sauvegardes");
    }
    else
    {
        if(!conn.connOpen())
        {
           qDebug() << "Failed to open the database";
           return;
        }
        else
        {
            conn.connOpen();
            QSqlQuery qry;
            qry.prepare("insert into Location (date_debut,date_fin,id_client,id_empl,id) "
                        "values ('"+date_deb+"','"+dat_fin+"','"+c1+"','"+e1+"','"+v1+"')");
            if(qry.exec())
            {
                QMessageBox::critical(this,"Enregistrement","Votre Location est effectuée vous pouvez chercher votre voiture au parc");
                QSqlQuery qry2;
                qry2.prepare("update Voitures set etat='Indisponible' where id='"+v1+"'");
                if(qry2.exec())
                {
                    QMessageBox::critical(this,"Enregistrement","Désormais cette voiture est indisponible");
                }
                else
                {
                    QMessageBox::critical(this,"error::",qry2.lastError().text());
                    conn.connClose();
                }
            }
            else
            {
                QMessageBox::critical(this,"error::",qry.lastError().text());
                conn.connClose();
            }
        }


    }
    conn.connClose();
    this->afficher_combo();
}


