#include "dbconnection.h"
#include <QSplashScreen>
#include <QTimer>

#include <QApplication>

int main(int argc, char *argv[])
{
    QApplication a(argc, argv);
    QPixmap image("../../Images/img_acceueil.jpg");
    QSplashScreen *splash = new QSplashScreen;
    splash-> setPixmap(image.scaled(862,500, Qt::KeepAspectRatio));
    splash-> show();
    Location_Voiture w;
    QTimer::singleShot(3500, splash,SLOT(close()));
    QTimer::singleShot(3500, &w,SLOT(show()));
    return a.exec();
}
