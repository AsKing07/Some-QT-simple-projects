#include "etatparc.h"
#include "ui_etatparc.h"
#include "accueil.h"
//#include "location_voiture.h"

Etatparc::Etatparc(QWidget *parent) :
    QDialog(parent),
    ui(new Ui::Etatparc)
{
    ui->setupUi(this);
}

Etatparc::~Etatparc()
{
    delete ui;
}

void Etatparc::on_pushButton_clicked()
{
    Location_Voiture conn;
    conn.connClose();
    this -> hide();
    Accueil retour;
    retour.exec();
}


void Etatparc::on_pushButton_2_clicked()
{
    QSqlQueryModel *model = new QSqlQueryModel;
    Location_Voiture conn;

    conn.connOpen();
    QSqlQuery *qry = new QSqlQuery(conn.mydb);

    qry -> prepare("select * from Voitures");
    qry -> exec();
    model -> setQuery(*qry);
    ui -> tableView ->setModel(model);
    conn.connClose();
    qDebug() << (model -> rowCount());

}

