#ifndef ETATPARC_H
#define ETATPARC_H

#include <QDialog>

namespace Ui {
class Etatparc;
}

class Etatparc : public QDialog
{
    Q_OBJECT

public:
    explicit Etatparc(QWidget *parent = nullptr);
    ~Etatparc();

private slots:
    void on_pushButton_clicked();

    void on_pushButton_2_clicked();

private:
    Ui::Etatparc *ui;
};

#endif // ETATPARC_H
