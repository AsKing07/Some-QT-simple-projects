#include "historique.h"
#include "ui_historique.h"
#include "accueil.h"

historique::historique(QWidget *parent) :
    QDialog(parent),
    ui(new Ui::historique)
{
    ui->setupUi(this);
    this->affiche_combo();
}

historique::~historique()
{
    delete ui;
}

void historique::on_back_clicked()
{
    Location_Voiture conn;
    conn.connClose();
    this -> hide();
    Accueil retour;
    retour.exec();
}

void historique::affiche_combo()
{
    Location_Voiture conn;
    QSqlQueryModel *modele_voi = new QSqlQueryModel();

    conn.connOpen();

    QSqlQuery *qry_voi=new QSqlQuery(conn.mydb);
    qry_voi->prepare("select id from Voitures");

    qry_voi->exec();
    modele_voi->setQuery(*qry_voi);

    ui -> comboBox-> setModel(modele_voi);
}


void historique::on_comboBox_currentTextChanged(const QString &arg1)
{
    QSqlQueryModel *model = new QSqlQueryModel;
    QSqlQueryModel *model1 = new QSqlQueryModel;
    Location_Voiture conn;
    QString id;


    conn.connOpen();
    QSqlQuery *qry = new QSqlQuery(conn.mydb);
    QSqlQuery *qry_etat = new QSqlQuery(conn.mydb);
    QSqlQuery qry1;

    qry -> prepare("select * from Location where id='"+arg1+"'");
    qry_etat -> prepare("select * from Voitures where id='"+arg1+"'");
    qry1.prepare("select * from Voitures where id='"+arg1+"'");
    qry -> exec();
    qry_etat -> exec();
    model -> setQuery(*qry);
    model1 ->setQuery(*qry_etat);
    ui -> tableView ->setModel(model);
    ui -> tableView_2 ->setModel(model1);
    if(qry1.exec())
    {
        while(qry1.next())
        {
            if(qry1.value(0).toString()==arg1)
            {
            ui->etat_voiture -> setText("La voiture est : "+qry1.value(5).toString());
            }
        }
    }


    conn.connClose();
    qDebug() << (model -> rowCount());
    qDebug() << (model1 -> rowCount());

}

