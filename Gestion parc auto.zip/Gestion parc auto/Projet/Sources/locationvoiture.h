#ifndef LOCATIONVOITURE_H
#define LOCATIONVOITURE_H

#include <QDialog>

namespace Ui {
class Locationvoiture;
}

class Locationvoiture : public QDialog
{
    Q_OBJECT

public:
    explicit Locationvoiture(QWidget *parent = nullptr);
    ~Locationvoiture();
    void afficher_combo();

private slots:
    void on_pushButton_clicked();

    void on_button_afficher_clicked();

    void on_buton_louer_clicked();


    void on_verification_clicked();

    void on_bouton_louer_clicked();

private:
    Ui::Locationvoiture *ui;
};

#endif // LOCATIONVOITURE_H
