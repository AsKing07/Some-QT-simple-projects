#include "location_voiture.h"
#include "ui_location_voiture.h"
#include "accueil.h"

Location_Voiture::Location_Voiture(QWidget *parent) :
    QDialog(parent),
    ui(new Ui::Location_Voiture)
{
    ui->setupUi(this);
    if(!connOpen())
    {
        ui -> statut_2 -> setText("Echec de la connexion");

    }
    else
    {
        ui -> statut_2 -> setText("Connecté...");
        connClose();
    }
}



Location_Voiture::~Location_Voiture()
{
    delete ui;
}




void Location_Voiture::on_log_bot_2_clicked()
{
    QString username,password;
    username = ui -> line_username_2 -> text();
    password = ui -> line_password_2 -> text();

    if(username.isEmpty()&&password.isEmpty())
    {
        ui -> statut_2 -> setText("Le nom d'utilisation et le mot de passe ne sont pas renseignés");
        QMessageBox::critical(this,"Remplissage","Le nom d'utilisation et le mot de passe ne sont pas renseignés");


    }
    else if(username.isEmpty())
    {
        ui -> statut_2 -> setText("Le nom d'utilisation n'est pas renseigné");
        QMessageBox::critical(this,"Remplissage","Le nom d'utilisation n'est pas renseignés");

    }
    else if(password.isEmpty())
    {
        ui -> statut_2 -> setText("Le mot de passe n'est pas renseignés");
        QMessageBox::critical(this,"Remplissage","Le mot de passe n'est pas renseignés");

    }


    else
    {
        if(!connOpen())
        {
           qDebug() << "Failed to open the database";
           return;
        }
        connOpen();
        QSqlQuery qry;
        qry.prepare("select * from Employes where username='"+username+"' and password='"+password+"'");
        if(qry.exec())
        {
            int count = 0;
            if(qry.value(3).toString()==username && qry.value(4).toString()==password)
            {
                count++;
            }

            while(qry.next())
            {
                if(qry.value(3).toString()==username && qry.value(4).toString()==password)
                {
                    count++;
                }
                }
                if(count==1)
                {
                    ui -> statut_2 -> setText("Nom d'utulisateur et Mot de Passe corrects");
                    connClose();
                    this -> hide();
                    Accueil acc;
                    acc.exec();
                }
                else if(count>1)
                {
                    ui -> statut_2 -> setText("Nom d'utulisateur et Mot de Passe corrects en doublons");
                    connClose();
                }
                else if(count<1)
                {
                    ui -> statut_2 -> setText("Nom d'utulisateur ou Mot de Passe incorrects");
                    connClose();
                }
        }
        }


}

