#ifndef VOITURES_H
#define VOITURES_H

#include <QDialog>

namespace Ui {
class Voitures;
}

class Voitures : public QDialog
{
    Q_OBJECT

public:
    explicit Voitures(QWidget *parent = nullptr);
    ~Voitures();

private slots:
    void on_pushButton_clicked();

    void on_Button_save_car_clicked();

    void on_Button_edit_car_clicked();

    void on_Button_remove_car_clicked();

    void on_Button_save_car_2_clicked();

private:
    Ui::Voitures *ui;
};

#endif // VOITURES_H
