#ifndef ACCUEIL_H
#define ACCUEIL_H

#include <QDialog>
#include <QMessageBox>
#include "location_voiture.h"

namespace Ui {
class Accueil;
}

class Accueil : public QDialog
{
    Q_OBJECT

public:
    explicit Accueil(QWidget *parent = nullptr);
    ~Accueil();


private slots:
    void on_bouton_employe_clicked();

    void on_bouton_client_clicked();

    void on_bouton_voiture_clicked();

    void on_bouton_location_clicked();

    void on_bouton_parc_clicked();

    void on_bouton_Se_Deconnecter_clicked();

    void on_bouton_historique_clicked();

private:
    Ui::Accueil *ui;
};

#endif // ACCUEIL_H
